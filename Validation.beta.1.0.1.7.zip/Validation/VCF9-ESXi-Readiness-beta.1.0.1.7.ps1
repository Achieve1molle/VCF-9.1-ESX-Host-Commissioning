
# VCF9-ESXi-Readiness-r6i6-UI-v5.4-fixed8a-release.ps1
[CmdletBinding()]
param(
  [switch]$NoRelaunch,
  [switch]$SignedOk,
  [switch]$NoAutoSign
)
$VerbosePreference='SilentlyContinue'
$ProgressPreference='SilentlyContinue'
$InformationPreference='Continue'
$ErrorActionPreference='Stop'

# --- Self-sign + relaunch (STA) ---------------------------------------------
function Ensure-SelfSigned {
  param([Parameter(Mandatory)][string]$TargetPath)
  try { $sig = Get-AuthenticodeSignature -FilePath $TargetPath -ErrorAction SilentlyContinue } catch { $sig = $null }
  if ($sig -and $sig.Status -eq 'Valid') { return $false }
  Write-Host "[SelfSign] Creating/trusting local code-signing cert and signing the script..."
  $subject = "CN=VCF9 Readiness Local Code Signing ($env:USERNAME@$env:COMPUTERNAME)"
  $cert = Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert -ErrorAction SilentlyContinue |
          Where-Object { $_.Subject -like 'CN=VCF9 Readiness Local Code Signing*' } |
          Sort-Object NotAfter -Descending | Select-Object -First 1
  if (-not $cert) {
    $cert = New-SelfSignedCertificate -Type CodeSigningCert -Subject $subject -CertStoreLocation 'Cert:\CurrentUser\My' -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 -KeyExportPolicy Exportable -NotAfter (Get-Date).AddYears(5)
  }
  try { $cert | Copy-Item -Destination 'Cert:\CurrentUser\Root' -Force -ErrorAction SilentlyContinue } catch {}
  try { $cert | Copy-Item -Destination 'Cert:\CurrentUser\TrustedPublisher' -Force -ErrorAction SilentlyContinue } catch {}
  try {
    try { Set-AuthenticodeSignature -FilePath $TargetPath -Certificate $cert -HashAlgorithm SHA256 -TimestampServer 'http://timestamp.digicert.com' -ErrorAction Stop | Out-Null }
    catch { Set-AuthenticodeSignature -FilePath $TargetPath -Certificate $cert -HashAlgorithm SHA256 -ErrorAction Stop | Out-Null }
    Write-Host "[SelfSign] Script signed."; return $true
  } catch { Write-Host ("[WARN ] Self-sign failed: {0}" -f $_.Exception.Message); return $false }
}
try { $pwsh = (Get-Process -Id $PID).Path } catch { $pwsh = $null }
if (-not $pwsh) { $pwsh = (Get-Command pwsh -ErrorAction SilentlyContinue)?.Source }
if (-not $pwsh) { $pwsh = Join-Path $PSHOME 'pwsh.exe' }
if (-not $NoAutoSign -and -not $SignedOk) {
  $didSign = Ensure-SelfSigned -TargetPath $PSCommandPath
  if ($didSign) { & $pwsh -NoProfile -ExecutionPolicy Bypass -STA -File "$PSCommandPath" -SignedOk -NoRelaunch; exit $LASTEXITCODE }
  else { Write-Host "[WARN ] Proceeding unsigned (self-sign not available)." }
}
if (-not $NoRelaunch) {
  if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    & $pwsh -NoProfile -ExecutionPolicy Bypass -STA -File "$PSCommandPath" -NoRelaunch -SignedOk
    exit $LASTEXITCODE
  }
}

# --- Paths, logging ----------------------------------------------------------
$script:ScriptBase = Split-Path -Parent $PSCommandPath
$script:RunBase    = (Get-Location).Path
$script:RunDir     = Join-Path $script:RunBase ("VCF9-Readiness-Run-" + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$null = New-Item -ItemType Directory -Path $script:RunDir -Force | Out-Null
$Global:LogFile = Join-Path $script:RunDir ("Readiness-" + (Get-Date -Format 'yyyyMMdd-HHmmss') + ".log")
"" | Out-File $Global:LogFile -Encoding UTF8 -Force
function Write-Log {
  param([Parameter(Mandatory)][string]$Message,[ValidateSet('INFO','WARN','ERROR')][string]$Level='INFO')
  $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff')
  $line = "[$ts][$Level] $Message"
  try { Add-Content -Path $Global:LogFile -Value $line -Encoding UTF8 -EA SilentlyContinue } catch {}
  try { if ($script:txtLog -and $script:txtLog.Dispatcher -and -not $script:txtLog.Dispatcher.HasShutdownStarted) { $null = $script:txtLog.Dispatcher.Invoke([Action]{ $script:txtLog.AppendText($line + "`r`n"); $script:txtLog.ScrollToEnd() }) } } catch {}
  Write-Host $line
}
Write-Log "Script start (r6i6)"

# === Quiet diagnostics (release) ============================================
function Write-Exception { param([string]$Context,[Parameter(ValueFromPipeline=$true)][System.Exception]$Exception) try{ $msg="{0}: {1}" -f $Context,$Exception.Message; Write-Log $msg 'ERROR' }catch{} }
function Try-Do { param([scriptblock]$Action,[string]$Label='Action') try{ & $Action } catch { $_.Exception | Write-Exception -Context $Label } }
try { Write-Log ("Diag: PS={0}; OS={1}; CLR={2}" -f $PSVersionTable.PSVersion,[System.Environment]::OSVersion.Version,[System.Environment]::Version) } catch {}
try { Write-Log ("Diag: ScriptPath={0}; RunDir={1}; WD={2}" -f $PSCommandPath,$script:RunDir,(Get-Location).Path) } catch {}

# --- Compatibility rules loader (JSON or DSL) -------------------------------
function Parse-CompatRulesText {
  param([string]$Text)
  $rules = @(); if ([string]::IsNullOrWhiteSpace($Text)) { return $rules }
  foreach($ln in ($Text -split "`n")){
    $l = $ln.Trim(); if([string]::IsNullOrWhiteSpace($l)){ continue }
    $r = [pscustomobject]@{ class=$null; match=$null; regex=$null; vid=$null; did=$null; driver=[pscustomobject]@{ name=$null; min=$null }; esxi=@(); note=$null }
    if($l -match '(?i)\bclass\s+(NIC|HBA|SSD)'){ $r.class = $Matches[1] }
    if($l -match '(?i)\bregex\s+(.+?)(?=\s+(driver|esxi|note|class|match|vid|did)\b|$)'){ $r.regex = $Matches[1].Trim() }
    if($l -match '(?i)\bmatch\s+(.+?)(?=\s+(driver|esxi|note|regex|class|vid|did)\b|$)'){ $r.match = $Matches[1].Trim() }
    if($l -match '(?i)\bdriver\s+name\s+(\S+)'){ $r.driver.name = $Matches[1] }
    if($l -match '(?i)\bdriver\s+min\s+(\S+)'){ $r.driver.min  = $Matches[1] }
    if($l -match '(?i)\bvid\s+(\S+)'){ $r.vid = $Matches[1] }
    if($l -match '(?i)\bdid\s+(\S+)'){ $r.did = $Matches[1] }
    if($l -match '(?i)\bnote\s+(.+?)(?=\s+(driver|esxi|class|match|regex|vid|did)\b|$)'){ $r.note=$Matches[1].Trim() }
    if($l -match '(?i)\besxi\s+(.+)$'){
      $toks = ($Matches[1].Trim() -split '\s+')
      $vers=@(); for($i=0;$i -lt $toks.Count;){ $cur=$toks[$i]
        if(($i+1) -lt $toks.Count -and $cur -match '^[0-9]+\.[0-9]+' -and $toks[$i+1] -match '^U[0-9]+'){ $vers += ($cur + ' ' + $toks[$i+1]); $i+=2 }
        else { $vers += $cur; $i++ }
      }
      $r.esxi = $vers
    }
    $rules += $r
  }
  return $rules
}
function Load-CompatRules { param([string]$Raw)
  if([string]::IsNullOrWhiteSpace($Raw)){ return @() }
  try { return ($Raw | ConvertFrom-Json -EA Stop) } catch { return (Parse-CompatRulesText -Text $Raw) }
}

# --- Environment checks ------------------------------------------------------
if ($PSVersionTable.PSVersion.Major -lt 7) { Write-Log "PowerShell 7+ required. Found: $($PSVersionTable.PSVersion)" 'ERROR'; throw "PowerShell 7+ required." }
try { Add-Type -AssemblyName PresentationCore,PresentationFramework,WindowsBase | Out-Null; Add-Type -AssemblyName System.Windows.Forms | Out-Null } catch { Write-Log ("WPF assembly load failed: {0}" -f $_.Exception.Message) 'ERROR'; throw }

# --- XAML (r6i visuals) ------------------------------------------------------
$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Achieve One—Leadership to Adapt—Expertise to Achieve" Height="900" Width="1480" WindowStartupLocation="CenterScreen"
        Background="#0F0F10" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="12">
  <Window.Resources>
    <SolidColorBrush x:Key="WinBg"    Color="#0F0F10"/>
    <SolidColorBrush x:Key="PanelBg"  Color="#171819"/>
    <SolidColorBrush x:Key="BorderBr" Color="#2E2F31"/>
    <SolidColorBrush x:Key="GridBg"   Color="#1B1C1E"/>
    <SolidColorBrush x:Key="GridBgAlt" Color="#1C1E21"/>
    <SolidColorBrush x:Key="LogBg"    Color="#0E0F10"/>
    <Style TargetType="GroupBox"><Setter Property="Background" Value="{StaticResource PanelBg}"/><Setter Property="BorderBrush" Value="{StaticResource BorderBr}"/><Setter Property="Margin" Value="8,6,8,8"/><Setter Property="Padding" Value="4"/><Setter Property="Foreground" Value="#FFFFFF"/></Style>
    <Style TargetType="Button"><Setter Property="Padding" Value="14,8"/><Setter Property="Margin" Value="6,0,0,6"/><Setter Property="MinWidth" Value="180"/><Setter Property="Width" Value="180"/><Setter Property="HorizontalAlignment" Value="Left"/></Style>
    <Style TargetType="TextBox"><Setter Property="Padding" Value="6,4"/><Setter Property="Background" Value="#131415"/><Setter Property="BorderBrush" Value="{StaticResource BorderBr}"/><Setter Property="Foreground" Value="#FFFFFF"/></Style>
    <Style TargetType="DataGrid"><Setter Property="Background" Value="{StaticResource GridBg}"/><Setter Property="Foreground" Value="#FFFFFF"/><Setter Property="BorderBrush" Value="{StaticResource BorderBr}"/><Setter Property="RowHeight" Value="24"/><Setter Property="ColumnHeaderHeight" Value="26"/><Setter Property="HeadersVisibility" Value="Column"/><Setter Property="GridLinesVisibility" Value="None"/><Setter Property="AlternatingRowBackground" Value="{StaticResource GridBgAlt}"/></Style>
    <Style TargetType="DataGridColumnHeader"><Setter Property="Background" Value="#202225"/><Setter Property="Foreground" Value="#FFFFFF"/><Setter Property="BorderBrush" Value="{StaticResource BorderBr}"/><Setter Property="FontWeight" Value="SemiBold"/></Style>
    <Style TargetType="DataGridCell"><Setter Property="Background" Value="{StaticResource GridBg}"/><Setter Property="Foreground" Value="#FFFFFF"/><Setter Property="BorderBrush" Value="{StaticResource BorderBr}"/><Setter Property="BorderThickness" Value="0,0,1,1"/></Style>
    <Style TargetType="CheckBox"><Setter Property="Foreground" Value="#FFFFFF"/></Style>
    <Style x:Key="ToolbarCombo" TargetType="ComboBox"><Setter Property="Height" Value="26"/><Setter Property="MinWidth" Value="160"/><Setter Property="VerticalContentAlignment" Value="Center"/><Setter Property="Padding" Value="6,0,6,0"/><Setter Property="Margin" Value="6,0,0,6"/></Style>
  </Window.Resources>
  <Grid Margin="10" Background="{StaticResource WinBg}">
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
      <RowDefinition Height="0.9*"/>
      <RowDefinition Height="Auto"/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
      <ColumnDefinition Width="3*"/>
      <ColumnDefinition Width="2*"/>
    </Grid.ColumnDefinitions>

    <GroupBox Grid.Row="0" Grid.ColumnSpan="2" Header="Prerequisites">
      <Grid>
        <Grid.ColumnDefinitions>
          <ColumnDefinition Width="*"/>
          <ColumnDefinition Width="*"/>
          <ColumnDefinition Width="Auto"/>
        </Grid.ColumnDefinitions>
        <StackPanel Grid.Column="0" Orientation="Vertical" Margin="6,8,10,4">
          <DockPanel LastChildFill="False" Margin="0,0,0,2"><TextBlock Text="PowerShell:" Margin="0,0,8,0"/><TextBlock x:Name="lblPS" Text="-"/></DockPanel>
          <DockPanel LastChildFill="False" Margin="0,0,0,2"><TextBlock Text="VMware.PowerCLI:" Margin="0,0,8,0"/><TextBlock x:Name="lblPCLI" Text="-"/></DockPanel>
          <DockPanel LastChildFill="False" Margin="0,0,0,2"><TextBlock Text="ImportExcel:" Margin="0,0,8,0"/><TextBlock x:Name="lblExcel" Text="-"/></DockPanel>
          <DockPanel LastChildFill="False" Margin="0,0,0,2"><TextBlock Text="OpenSSH client:" Margin="0,0,8,0"/><TextBlock x:Name="lblOpenSSH" Text="-"/></DockPanel>
          <DockPanel LastChildFill="False" Margin="0,0,0,2"><TextBlock Text="vSAN HCL JSON:" Margin="0,0,8,0"/><TextBlock x:Name="lblVsanJson" Text="-"/></DockPanel>
        </StackPanel>
        <StackPanel Grid.Column="1" Orientation="Vertical" Margin="6,0,10,0" VerticalAlignment="Center">
          <CheckBox x:Name="chkUseBCG" Content="Enable Broadcom Compatibility Guide (BCG) checks" IsChecked="True"/>
          <CheckBox x:Name="chkUseVSANJson" Content="Use offline vSAN HCL (all.json) if available" IsChecked="True"/>
          <CheckBox x:Name="chkVsanResidue" Content="Check for vSAN residue (fail if found)"/>
        </StackPanel>
        <StackPanel Grid.Column="2" Orientation="Vertical" HorizontalAlignment="Left" Margin="8,0,0,0" VerticalAlignment="Top">
          <Button x:Name="btnInstallPCLI" Content="Install PowerCLI"/>
          <Button x:Name="btnInstallExcel" Content="Install ImportExcel"/>
          <Button x:Name="btnRecheck" Content="Recheck"/>
          <Button x:Name="btnGetVsanHcl" Content="Download vSAN HCL JSON"/>
        </StackPanel>
      </Grid>
    </GroupBox>

    <GroupBox Grid.Row="1" Grid.ColumnSpan="2" Header="ESXi Targets (stand-alone hosts)">
      <DockPanel>
        <StackPanel DockPanel.Dock="Top" Orientation="Horizontal" Margin="6,10,6,10">
          <Button x:Name="btnAdd" Content="Add Row"/>
          <Button x:Name="btnRemove" Content="Remove Selected"/>
          <Button x:Name="btnLoad" Content="Load Targets"/>
          <Button x:Name="btnSave" Content="Save Targets"/>
          <TextBlock Text="Target ESXi Version:" Margin="24,0,8,0" VerticalAlignment="Center"/>
          <ComboBox x:Name="cmbEsxiTarget" Style="{StaticResource ToolbarCombo}">
            <ComboBoxItem Content="9.0.1.0" IsSelected="True"/>
            <ComboBoxItem Content="9.0.0.1"/>
            <ComboBoxItem Content="8.0 U3"/>
            <ComboBoxItem Content="8.0 U2"/>
            <ComboBoxItem Content="8.0 U1"/>
            <ComboBoxItem Content="8.0"/>
          </ComboBox>
        </StackPanel>
        <DataGrid x:Name="grid" AutoGenerateColumns="False" CanUserAddRows="False" CanUserDeleteRows="True" IsReadOnly="False" Margin="6" MinHeight="300" VerticalAlignment="Stretch">
          <DataGrid.Columns>
            <DataGridTextColumn Header="Host / FQDN" Binding="{Binding TargetHost}" Width="2*"/>
            <DataGridTextColumn Header="Username"   Binding="{Binding Username}"  Width="*"/>
            <DataGridTemplateColumn Header="Password" Width="*">
              <DataGridTemplateColumn.CellTemplate>
                <DataTemplate><PasswordBox Tag="{Binding}" PasswordChar="●"/></DataTemplate>
              </DataGridTemplateColumn.CellTemplate>
            </DataGridTemplateColumn>
            <DataGridTextColumn Header="Port" Binding="{Binding Port}" Width="0.6*"/>
          </DataGrid.Columns>
        </DataGrid>
      </DockPanel>
    </GroupBox>

    <GroupBox Grid.Row="2" Grid.Column="0" Header="Per-host Results" Margin="8,0,4,0">
      <DataGrid x:Name="gridResults" AutoGenerateColumns="False" CanUserAddRows="False" IsReadOnly="True" Margin="8">
        <DataGrid.Columns>
          <DataGridTextColumn Header="Host"   Binding="{Binding Host}"   Width="2*"/>
          <DataGridTextColumn Header="Check"  Binding="{Binding Check}"  Width="*"/>
          <DataGridTextColumn Header="Status" Binding="{Binding Status}" Width="*"/>
          <DataGridTextColumn Header="Detail" Binding="{Binding Detail}" Width="3*"/>
        </DataGrid.Columns>
      </DataGrid>
    </GroupBox>

    <GroupBox Grid.Row="2" Grid.Column="1" Header="Log" Margin="4,0,8,0">
      <DockPanel>
        <Button x:Name="btnOpenLog" Content="Open Log" DockPanel.Dock="Top" HorizontalAlignment="Right" Margin="8,6,8,0"/>
        <TextBox x:Name="txtLog" Margin="8" FontFamily="Consolas" FontSize="12" AcceptsReturn="True" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto" IsReadOnly="True" Background="{StaticResource LogBg}" Foreground="#C9C9C9"/>
      </DockPanel>
    </GroupBox>

    <GroupBox Grid.Row="3" Grid.ColumnSpan="2" Header="Actions" Margin="0,8,0,0">
      <DockPanel LastChildFill="False" Margin="0,8,0,0">
        <StackPanel Orientation="Horizontal" DockPanel.Dock="Left" Margin="6,0,6,0">
          <TextBox x:Name="txtReports" Width="420"/>
          <Button x:Name="btnBrowseReports" Content="Browse"/>
          <Button x:Name="btnOpenOut"      Content="Open Reports"/>
        </StackPanel>
        <StackPanel Orientation="Horizontal" DockPanel.Dock="Right" Margin="6,0,6,0">
          <Button x:Name="btnTest"      Content="Test Connection"/>
          <Button x:Name="btnRun"       Content="Run Readiness"/>
          <Button x:Name="btnCancel"    Content="Cancel" IsEnabled="False"/>
          <Button x:Name="btnOpenExcel" Content="Open Last Excel"/>
          <Button x:Name="btnClose"     Content="Close"/>
        </StackPanel>
      </DockPanel>
    </GroupBox>

  </Grid>
</Window>
'@
try { $script:window = [Windows.Markup.XamlReader]::Parse($xaml) } catch { Write-Log ("XAML parse failed: {0}" -f $_.Exception.Message) 'ERROR'; throw }
$script:window.Title = 'Achieve One—Leadership to Adapt—Expertise to Achieve'

# find named controls
$names = 'lblPS','lblPCLI','lblExcel','lblOpenSSH','lblVsanJson','chkUseBCG','chkUseVSANJson','chkVsanResidue','btnInstallPCLI','btnInstallExcel','btnRecheck','btnGetVsanHcl','grid','gridResults','btnAdd','btnRemove','btnLoad','btnSave','cmbEsxiTarget','txtLog','btnOpenLog','btnOpenOut','btnBrowseReports','txtReports','btnTest','btnRun','btnCancel','btnOpenExcel','btnClose'
foreach($n in $names){ Set-Variable -Name $n -Scope Script -Value ($script:window.FindName($n)) }
$script:txtReports.Text = $script:RunBase

# quiet global exception hooks
try {
  if ([System.Windows.Application]::Current) {
    [void][System.Windows.Application]::Current.Add_DispatcherUnhandledException({ param($s,$e) try { Write-Log ("[UI] Unhandled exception: {0}" -f $e.Exception.Message) 'ERROR' } catch {}; $e.Handled = $true })
  }
  [void][AppDomain]::CurrentDomain.add_UnhandledException({ param($s,$e) try { if ($e.ExceptionObject) { Write-Log ("[AppDomain] Unhandled: " + $e.ExceptionObject.ToString()) 'ERROR' } } catch {} })
} catch {}

# data sources & bindings
$script:Targets = New-Object System.Collections.ObjectModel.ObservableCollection[psobject]
$script:Rows    = New-Object System.Collections.ObjectModel.ObservableCollection[psobject]
$script:grid.ItemsSource        = $script:Targets
$script:gridResults.ItemsSource = $script:Rows

# Password binding
$handler = [System.Windows.RoutedEventHandler]{ param($sender,$e) try { $pwd=[System.Windows.Controls.PasswordBox]$e.OriginalSource; $row=$pwd.Tag; if ($row -and ($row.PSObject.Properties['Password'])) { $row.Password = $pwd.Password } } catch {} }
$script:grid.AddHandler([System.Windows.Controls.PasswordBox]::PasswordChangedEvent, $handler)

# helpers
Add-Type -AssemblyName System.Windows.Forms | Out-Null
function Do-Events { [System.Windows.Forms.Application]::DoEvents() | Out-Null }
function Has-Module([string]$Name) { Get-Module -ListAvailable -Name $Name | Select-Object -First 1 }
function Try-Import([string]$Name) { try { Import-Module $Name -ErrorAction Stop | Out-Null; $true } catch { $false } }
function Set-StatusText([System.Windows.Controls.TextBlock]$Label,[string]$Text,[string]$State){ $Label.Text=$Text; switch($State){ 'OK'{$Label.Foreground=[Windows.Media.Brushes]::LightGreen} 'WARN'{$Label.Foreground=[Windows.Media.Brushes]::Gold} 'FAIL'{$Label.Foreground=[Windows.Media.Brushes]::Tomato} default{$Label.Foreground=[Windows.Media.Brushes]::White} } }
function Normalize-Text([string]$s){ if([string]::IsNullOrWhiteSpace($s)){return $s}; ($s -replace '\(R\)|\(TM\)','' -replace 'CPU','' -replace '@.*$','' -replace '\s+',' ').Trim() }
function Compare-Version([string]$a,[string]$b){ if([string]::IsNullOrWhiteSpace($a) -or [string]::IsNullOrWhiteSpace($b)){return 0}; $pa=$a -split '[^0-9]+' | ?{$_}; $pb=$b -split '[^0-9]+' | ?{$_}; $len=[Math]::Max($pa.Count,$pb.Count); for($i=0;$i -lt $len;$i++){ $va=if($i -lt $pa.Count){[int]$pa[$i]}else{0}; $vb=if($i -lt $pb.Count){[int]$pb[$i]}else{0}; if($va -gt $vb){return 1}elseif($va -lt $vb){return -1} }; 0 }

# prereqs (no ternaries)
function Prereq-Check{
  $ok=$true
  $isPS7 = $PSVersionTable.PSVersion.Major -ge 7
  if ($isPS7) { Set-StatusText -Label $script:lblPS -Text ("PowerShell {0}" -f $PSVersionTable.PSVersion) -State 'OK' } else { Set-StatusText -Label $script:lblPS -Text ("PowerShell {0}" -f $PSVersionTable.PSVersion) -State 'FAIL'; $ok=$false }
  $sshOK = (Get-Command ssh -EA SilentlyContinue) -and (Get-Command scp -EA SilentlyContinue)
  if ($sshOK) { Set-StatusText -Label $script:lblOpenSSH -Text 'Found' -State 'OK' } else { Set-StatusText -Label $script:lblOpenSSH -Text 'Not found' -State 'WARN' }
  $hasPCLI = Has-Module 'VMware.VimAutomation.Core'
  if ($hasPCLI) { Try-Import 'VMware.VimAutomation.Core' | Out-Null; Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false -EA SilentlyContinue | Out-Null; Set-StatusText -Label $script:lblPCLI -Text 'Found' -State 'OK' } else { Set-StatusText -Label $script:lblPCLI -Text 'Not found' -State 'FAIL'; $ok = $false }
  $hasExcel = Has-Module 'ImportExcel'
  if ($hasExcel) { Try-Import 'ImportExcel' | Out-Null; Set-StatusText -Label $script:lblExcel -Text 'Found' -State 'OK' } else { Set-StatusText -Label $script:lblExcel -Text 'Not found' -State 'WARN' }
  $all1 = Join-Path $script:RunBase   'all.json'
  $all2 = Join-Path $script:ScriptBase 'all.json'
  $vsanFound = (Test-Path $all1) -or (Test-Path $all2)
  if ($vsanFound) { Set-StatusText -Label $script:lblVsanJson -Text 'Found' -State 'OK' } else { Set-StatusText -Label $script:lblVsanJson -Text 'Not found (optional)' -State 'WARN' }
  if ($script:btnRun) { $script:btnRun.IsEnabled = $ok }
  return $ok
}
$null = Prereq-Check

# Buttons (wrapped with Try-Do, no message boxes)
$script:btnAdd.Add_Click({ Try-Do {
  $row = [pscustomobject]@{ TargetHost=''; Username='root'; Password=''; Port=443 }
  [void]$script:Targets.Add($row)
  $null = $script:window.Dispatcher.BeginInvoke([Action]{ try { if ($script:grid -and $script:Targets.Count -gt 0) { $script:grid.UpdateLayout(); $script:grid.ScrollIntoView($script:Targets[$script:Targets.Count-1]); if ($script:grid.Columns.Count -gt 0) { $ci = New-Object System.Windows.Controls.DataGridCellInfo($script:Targets[$script:Targets.Count-1], $script:grid.Columns[0]); $script:grid.CurrentCell = $ci; $script:grid.BeginEdit() } } } catch { $_.Exception | Write-Exception -Context 'btnAdd-UI' } }, [System.Windows.Threading.DispatcherPriority]::Background)
} 'btnAdd' })
$script:btnRemove.Add_Click({ Try-Do { $sel=@($script:grid.SelectedItems); foreach($r in $sel){ [void]$script:Targets.Remove($r) } } 'btnRemove' })
$script:btnLoad.Add_Click({ Try-Do { $dlg=New-Object Microsoft.Win32.OpenFileDialog; $dlg.Filter="CSV files (*.csv)|*.csv|All files (*.*)|*.*"; $dlg.Title="Select targets CSV (TargetHost,Username,[Password],[Port])"; if($dlg.ShowDialog() -eq $true){ $csv=Import-Csv -Path $dlg.FileName; $script:Targets.Clear(); foreach($row in $csv){ $pwd = if($row.PSObject.Properties['Password']){ $row.Password } else { '' }; $port = if($row.PSObject.Properties['Port']){ [int]$row.Port } else { 443 }; $script:Targets.Add([pscustomobject]@{ TargetHost=$row.TargetHost; Username=$row.Username; Password=$pwd; Port=$port }) }; Write-Log ("Loaded {0} target(s)" -f $script:Targets.Count) } } 'btnLoad' })
$script:btnSave.Add_Click({ Try-Do { $dlg=New-Object Microsoft.Win32.SaveFileDialog; $dlg.Filter="CSV files (*.csv)|*.csv|All files (*.*)|*.*"; $dlg.Title="Save targets CSV"; $dlg.FileName="Targets.csv"; if($dlg.ShowDialog() -eq $true){ $script:Targets | Export-Csv -Path $dlg.FileName -NoTypeInformation -Encoding UTF8; Write-Log ("Saved targets -> {0}" -f $dlg.FileName) } } 'btnSave' })
$script:btnInstallPCLI.Add_Click({ Try-Do { Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -EA SilentlyContinue | Out-Null; Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -EA SilentlyContinue | Out-Null; Install-Module VMware.PowerCLI -Scope CurrentUser -Force -AllowClobber -AcceptLicense -EA Stop; Try-Import 'VMware.VimAutomation.Core' | Out-Null; Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false -EA SilentlyContinue | Out-Null; Write-Log "VMware.PowerCLI installed/updated."; Prereq-Check | Out-Null } 'btnInstallPCLI' })
$script:btnInstallExcel.Add_Click({ Try-Do { Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -EA SilentlyContinue | Out-Null; Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -EA SilentlyContinue | Out-Null; Install-Module ImportExcel -Scope CurrentUser -Force -EA Stop; Try-Import 'ImportExcel' | Out-Null; Write-Log "ImportExcel installed/updated."; Prereq-Check | Out-Null } 'btnInstallExcel' })
$script:btnRecheck.Add_Click({ Try-Do { Prereq-Check | Out-Null } 'btnRecheck' })
$script:btnGetVsanHcl.Add_Click({ Try-Do { Start-Process "https://storage.googleapis.com/vsan-hcl-updates/all.json" } 'btnGetVsanHcl' })
$script:btnBrowseReports.Add_Click({ Try-Do { $dlg=New-Object System.Windows.Forms.FolderBrowserDialog; $dlg.SelectedPath=$script:RunBase; if($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){ $script:RunBase=$dlg.SelectedPath; $script:txtReports.Text=$script:RunBase } } 'btnBrowseReports' })
$script:btnOpenOut.Add_Click({ Try-Do { if(Test-Path $script:RunDir){ Start-Process explorer.exe $script:RunDir } else { Start-Process explorer.exe $script:RunBase } } 'btnOpenOut' })
$script:btnOpenLog.Add_Click({ Try-Do { if(Test-Path $Global:LogFile){ Start-Process notepad.exe $Global:LogFile } } 'btnOpenLog' })
$script:btnOpenExcel.Add_Click({ Try-Do { $last=Get-ChildItem -Path $script:RunDir -Filter '*.xlsx' | Sort-Object LastWriteTime -Descending | Select-Object -First 1; if($last){ Start-Process $last.FullName } } 'btnOpenExcel' })
$script:btnClose.Add_Click({ Try-Do { $script:window.Close() } 'btnClose' })

# Jobs helper
try { Import-Module ThreadJob -ErrorAction SilentlyContinue | Out-Null } catch {}
function Enable-RunButtons($enable){ $script:btnRun.IsEnabled=$enable; $script:btnTest.IsEnabled=$enable; $script:btnCancel.IsEnabled = -not $enable }
$script:RunJobs = New-Object System.Collections.Generic.List[System.Management.Automation.Job]

# Test Connection (wrapped)
$script:btnTest.Add_Click({ Try-Do {
  if (-not (Has-Module 'VMware.VimAutomation.Core')) { Write-Log "Install VMware.PowerCLI first." 'WARN'; return }
  Try-Import 'VMware.VimAutomation.Core' | Out-Null
  Import-Module VMware.VimAutomation.Vds -ErrorAction SilentlyContinue | Out-Null
  Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false -EA SilentlyContinue | Out-Null
  Enable-RunButtons $false
  Write-Log "Starting test(s)..."
  $script:Rows.Clear(); $script:gridResults.Items.Refresh(); $script:RunJobs.Clear()
  $targets = @($script:Targets | ForEach-Object { $_ })
  foreach($t in $targets){
    if([string]::IsNullOrWhiteSpace($t.TargetHost) -or [string]::IsNullOrWhiteSpace($t.Username)){
      $script:Rows.Add([pscustomobject]@{Host=$t.TargetHost;Check='Input';Status='Info';Detail='Host & Username required'}) | Out-Null
      $script:gridResults.Items.Refresh(); continue
    }
    $TargetHost=$t.TargetHost; $User=$t.Username; $Pass=$t.Password
    $job = Start-ThreadJob -ArgumentList $TargetHost,$User,$Pass -ScriptBlock {
      param($TargetHost,$User,$Pass)
      function Load-CompatRules { param([string]$Raw) if([string]::IsNullOrWhiteSpace($Raw)){ return @() } try { return ($Raw | ConvertFrom-Json -EA Stop) } catch { return @() } }
      try {
        Import-Module VMware.VimAutomation.Core -ErrorAction Stop | Out-Null
        Import-Module VMware.VimAutomation.Vds  -ErrorAction SilentlyContinue | Out-Null
        Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false -EA SilentlyContinue | Out-Null
        $vi = Connect-VIServer -Server $TargetHost -User $User -Password $Pass -Force -WarningAction SilentlyContinue -ErrorAction Stop
        try { $ver = (Get-View ServiceInstance).Content.About.FullName; [pscustomobject]@{Host=$TargetHost; Check='Connect'; Status='Pass'; Detail=$ver} }
        finally { try { if($vi){ Disconnect-VIServer -Server $vi -Force -Confirm:$false -EA SilentlyContinue | Out-Null } } catch { } }
      } catch { [pscustomobject]@{Host=$TargetHost; Check='Connect'; Status='Fail'; Detail=$_.Exception.Message} }
    }
    [void]$script:RunJobs.Add($job)
  }
  while($script:RunJobs.Where({ $_.State -in 'Running','NotStarted' }).Count){ Start-Sleep -Milliseconds 150; Do-Events }
  foreach($j in @($script:RunJobs)){
    try { $res=Receive-Job -Job $j -ErrorAction SilentlyContinue; if($res){ $script:Rows.Add($res) | Out-Null; $script:gridResults.Items.Refresh(); Write-Log ("[{0}] Test: {1} — {2}" -f $res.Host,$res.Status,$res.Detail) } }
    catch { Write-Log ("Test job error: {0}" -f $_.Exception.Message) 'ERROR' }
    finally { try { Remove-Job -Job $j -Force -EA SilentlyContinue } catch {}; [void]$script:RunJobs.Remove($j) }
  }
  Enable-RunButtons $true
} 'btnTest' })

# Run Readiness (with neighbor clarity + BCG JSON/DSL + IP warn)
$script:btnRun.Add_Click({ Try-Do {
  if (-not (Has-Module 'VMware.VimAutomation.Core')) { Write-Log "Install VMware.PowerCLI first." 'WARN'; return }
  Try-Import 'VMware.VimAutomation.Core' | Out-Null
  Import-Module VMware.VimAutomation.Vds -ErrorAction SilentlyContinue | Out-Null
  Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false -EA SilentlyContinue | Out-Null
  Enable-RunButtons $false
  Write-Log "==== Starting readiness ===="
  $EsxTarget    = $script:cmbEsxiTarget.Text
  $UseBCG       = [bool]$script:chkUseBCG.IsChecked
  $CheckResidue = [bool]$script:chkVsanResidue.IsChecked

  # Load BCG files (JSON or DSL)
  $BcgCpuRaw=$null; $BcgIoRaw=$null; $BcgSsdRaw=$null
  if ($UseBCG) {
    foreach($fn in 'bcg_cpu.json','bcg_io.json','bcg_ssd.json'){
      $p1=Join-Path $script:RunBase $fn; $p2=Join-Path $script:ScriptBase $fn
      if (Test-Path $p1) { if($fn -eq 'bcg_cpu.json'){ $BcgCpuRaw=Get-Content $p1 -Raw } elseif($fn -eq 'bcg_io.json'){ $BcgIoRaw=Get-Content $p1 -Raw } else { $BcgSsdRaw=Get-Content $p1 -Raw } }
      elseif (Test-Path $p2) { if($fn -eq 'bcg_cpu.json'){ $BcgCpuRaw=Get-Content $p2 -Raw } elseif($fn -eq 'bcg_io.json'){ $BcgIoRaw=Get-Content $p2 -Raw } else { $BcgSsdRaw=Get-Content $p2 -Raw } }
    }
  }

  $script:Rows.Clear(); $script:gridResults.Items.Refresh(); $script:RunJobs.Clear()
  $targets = @($script:Targets | ForEach-Object { $_ })
  foreach($t in $targets){
    if([string]::IsNullOrWhiteSpace($t.TargetHost) -or [string]::IsNullOrWhiteSpace($t.Username)){
      $script:Rows.Add([pscustomobject]@{Host=$t.TargetHost;Check='Run';Status='Fail';Detail='Missing Host/Username'}) | Out-Null
      $script:gridResults.Items.Refresh(); continue
    }
    Write-Log ("Queueing checks on {0}" -f $t.TargetHost)

    $TargetHost=$t.TargetHost; $User=$t.Username; $Pass=$t.Password; $Port = if($t.Port){[int]$t.Port}else{443}
    $job = Start-ThreadJob -ArgumentList $TargetHost,$User,$Pass,$EsxTarget,$UseBCG,$CheckResidue,$BcgCpuRaw,$BcgIoRaw,$BcgSsdRaw -ScriptBlock {
      param($TargetHost,$User,$Pass,$EsxTarget,$UseBCG,$CheckResidue,$BcgCpuRaw,$BcgIoRaw,$BcgSsdRaw)

      function Parse-CompatRulesText {
        param([string]$Text)
        $rules = @(); if ([string]::IsNullOrWhiteSpace($Text)) { return $rules }
        foreach($ln in ($Text -split "`n")){
          $l = $ln.Trim(); if([string]::IsNullOrWhiteSpace($l)){ continue }
          $r = [pscustomobject]@{ class=$null; match=$null; regex=$null; vid=$null; did=$null; driver=[pscustomobject]@{ name=$null; min=$null }; esxi=@(); note=$null }
          if($l -match '(?i)\bclass\s+(NIC|HBA|SSD)'){ $r.class = $Matches[1] }
          if($l -match '(?i)\bregex\s+(.+?)(?=\s+(driver|esxi|note|class|match|vid|did)\b|$)'){ $r.regex = $Matches[1].Trim() }
          if($l -match '(?i)\bmatch\s+(.+?)(?=\s+(driver|esxi|note|regex|class|vid|did)\b|$)'){ $r.match = $Matches[1].Trim() }
          if($l -match '(?i)\bdriver\s+name\s+(\S+)'){ $r.driver.name = $Matches[1] }
          if($l -match '(?i)\bdriver\s+min\s+(\S+)'){ $r.driver.min  = $Matches[1] }
          if($l -match '(?i)\bvid\s+(\S+)'){ $r.vid = $Matches[1] }
          if($l -match '(?i)\bdid\s+(\S+)'){ $r.did = $Matches[1] }
          if($l -match '(?i)\bnote\s+(.+?)(?=\s+(driver|esxi|class|match|regex|vid|did)\b|$)'){ $r.note=$Matches[1].Trim() }
          if($l -match '(?i)\besxi\s+(.+)$'){
            $toks = ($Matches[1].Trim() -split '\s+')
            $vers=@(); for($i=0;$i -lt $toks.Count;){ $cur=$toks[$i]
              if(($i+1) -lt $toks.Count -and $cur -match '^[0-9]+\.[0-9]+' -and $toks[$i+1] -match '^U[0-9]+'){ $vers += ($cur + ' ' + $toks[$i+1]); $i+=2 }
              else { $vers += $cur; $i++ }
            }
            $r.esxi = $vers
          }
          $rules += $r
        }
        return $rules
      }
      function Load-CompatRules { param([string]$Raw)
        if([string]::IsNullOrWhiteSpace($Raw)){ return @() }
        try { return ($Raw | ConvertFrom-Json -EA Stop) } catch { return (Parse-CompatRulesText -Text $Raw) }
      }
      function Normalize-Text([string]$s){ if(-not $s){ return $s } ($s -replace '\(R\)|\(TM\)','' -replace 'CPU','' -replace '@.*$','' -replace '\s+',' ').Trim() }
      function Compare-Version([string]$a,[string]$b){ if(-not $a -or -not $b){return 0}; $pa=$a -split '[^0-9]+' | ?{$_}; $pb=$b -split '[^0-9]+' | ?{$_}; $len=[Math]::Max($pa.Count,$pb.Count); for($i=0;$i -lt $len;$i++){ $va=if($i -lt $pa.Count){[int]$pa[$i]}else{0}; $vb=if($i -lt $pb.Count){[int]$pb[$i]}else{0}; if($va -gt $vb){return 1}elseif($va -lt $vb){return -1} }; 0 }

      $rows = New-Object System.Collections.Generic.List[psobject]
      try {
        Import-Module VMware.VimAutomation.Core -ErrorAction Stop | Out-Null
        Import-Module VMware.VimAutomation.Vds  -ErrorAction SilentlyContinue | Out-Null
        Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false -EA SilentlyContinue | Out-Null

        # Warn if IP target (affects TLS CN/SAN)
        if ($TargetHost -match '^(?:\d{1,3}\.){3}\d{1,3}$' -or $TargetHost -match '^(?:\[?[0-9a-fA-F:]+\]?)$') {
          $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Input';Status='Warn';Detail='TargetHost is an IP; use FQDN for TLS CN/SAN match to avoid certificate warnings'}) | Out-Null
        }

        $vi = Connect-VIServer -Server $TargetHost -User $User -Password $Pass -Force -WarningAction SilentlyContinue -EA Stop
        try {
          $vmh = Get-VMHost -Server $vi

          # NTP
          try {
            $ntps = $vmh | Get-VMHostNtpServer -EA SilentlyContinue
            $svc  = $vmh | Get-VMHostService | Where-Object { $_.Key -eq 'ntpd' }
            $statusNtp = 'Fail'; if ($ntps) { $statusNtp = 'Pass' }
            $rows.Add([pscustomobject]@{Host=$TargetHost;Check='NTP Servers';Status=$statusNtp;Detail=($ntps -join ',')}) | Out-Null
            $statusPol = 'Fail'; if ($svc -and ($svc.Policy -eq 'on' -or $svc.Running)) { $statusPol = 'Pass' }
            $rows.Add([pscustomobject]@{Host=$TargetHost;Check='NTP Startup Policy';Status=$statusPol;Detail=$svc.Policy}) | Out-Null
          } catch {}

          # Certificate (with IP -> Warn handling)
          try {
            $tcp = New-Object System.Net.Sockets.TcpClient; $tcp.Connect($TargetHost,443)
            $ssl = New-Object System.Net.Security.SslStream($tcp.GetStream(),$false,({$true}))
            $ssl.AuthenticateAsClient($TargetHost)
            $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($ssl.RemoteCertificate)
            $dns=@(); foreach($ext in $cert.Extensions){ if($ext.Oid.FriendlyName -eq 'Subject Alternative Name'){ $san=$ext.Format($true); $dns += ($san -split '[\r\n]' | Where-Object { $_ -match 'DNS Name=(.+)$' } | ForEach-Object { ($Matches[1]).Trim() }) } }
            $cn  = if($cert.Subject -match 'CN\s*=\s*([^,]+)'){ $Matches[1] } else { '' }
            $dom = (( $TargetHost -split '\.',2 ) | Select-Object -Skip 1)
            $wild= $false; if ($dom) { if ($dns -contains ("*."+$dom)) { $wild=$true } }
            $ok  = $false; if (($TargetHost -ieq $cn) -or ($dns -contains $TargetHost) -or $wild) { $ok=$true }
            $statusCert = 'Fail'; $detailCert=("CN={0}; SAN={1}" -f $cn,($dns -join ','))
            if ($ok) { $statusCert='Pass' }
            elseif ($TargetHost -match '^(?:\d{1,3}\.){3}\d{1,3}$' -or $TargetHost -match '^(?:\[?[0-9a-fA-F:]+\]?)$') { $statusCert='Warn'; $detailCert += '; Using IP—FQDN required for CN/SAN match' }
            $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Server Certificate';Status=$statusCert;Detail=$detailCert}) | Out-Null
          } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Server Certificate';Status='Unknown';Detail=$_.Exception.Message}) | Out-Null } finally { try { $ssl.Dispose() } catch {}; try { $tcp.Dispose() } catch {} }

          # vSAN residue
          if ($CheckResidue) {
            try { $cli = Get-EsxCli -VMHost $vmh -V2; $text=''; try { $list=$cli.vsan.storage.list.Invoke(); $text = ($list | Out-String) } catch {}; $hit=$false; if($text){ if ($text -match '(?i)\bvsan\b' -and ($text -match '(?i)inuse|claimed|disk\s*group|uuid')) { $hit=$true } }; $statusResid='Pass'; $detailResid='No residue detected'; if ($hit){ $statusResid='Fail'; $detailResid='Leftover vSAN claim/partitions detected' }; $rows.Add([pscustomobject]@{Host=$TargetHost;Check='vSAN Residue';Status=$statusResid;Detail=$detailResid}) | Out-Null } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='vSAN Residue';Status='Unknown';Detail=$_.Exception.Message}) | Out-Null }
          }

          # CPU BCG
          if ($UseBCG) {
            if ($BcgCpuRaw) {
              try { $bcg=Load-CompatRules $BcgCpuRaw; $view=$vmh | Get-View -Property Name,Hardware; $cpuRaw=($view.Hardware.CpuPkg | Select-Object -First 1).Description; $cpu=Normalize-Text $cpuRaw; $match=$null; foreach($e in $bcg){ $m=Normalize-Text $e.match; $hit=$false; if ($m -and ($cpu -like ("*"+$m+"*"))) { $hit=$true } elseif ($e.PSObject.Properties['regex']) { try { if ($cpuRaw -match $e.regex) { $hit=$true } } catch {} } if ($hit) { $match=$e; break } }; if ($match -and $match.esxi) { $supported=$false; if ($match.esxi -contains $EsxTarget) { $supported=$true }; $st='Fail'; if ($supported) { $st='Pass' }; $rows.Add([pscustomobject]@{Host=$TargetHost;Check='CPU BCG';Status=$st;Detail=("CPU={0}; Match={1}; Supports=[{2}]" -f $cpuRaw,$match.match,($match.esxi -join ','))}) } else { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='CPU BCG';Status='Unknown';Detail=("CPU={0}; No match in bcg_cpu.json" -f $cpuRaw)}) } } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='CPU BCG';Status='Unknown';Detail=$_.Exception.Message}) }
            } else { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='CPU BCG';Status='Unknown';Detail='bcg_cpu.json not found'}) | Out-Null }
          }

          # IO BCG (NIC/HBA)
          if ($UseBCG) {
            if ($BcgIoRaw) {
              try {
                $io = Load-CompatRules $BcgIoRaw
                $cli2= Get-EsxCli -VMHost $vmh -V2
                $vibs=@(); try { $vibs = $cli2.software.vib.list.Invoke() } catch {}
                $pnics=@(); try { $pnics= Get-VMHostPnic -VMHost $vmh -EA SilentlyContinue } catch {}
                $hbas =@(); try { $hbas = Get-VMHostHba  -VMHost $vmh -EA SilentlyContinue | Where-Object { $_.Model -and ($_.Model -notmatch '(?i)iSCSI Software Adapter') } } catch {}
                $pci  =@(); try { $pci  = $cli2.hardware.pci.list.Invoke() } catch {}
                $drvVer=@{}; foreach($v in $vibs){ if($v -and $v.Name){ $drvVer[$v.Name.ToLower()]=$v.Version } }

                foreach($n in $pnics){
                  $drv=$n.Driver; $ver= if($drv -and $drvVer.ContainsKey($drv.ToLower())){ $drvVer[$drv.ToLower()] } else { '' }
                  $detail = "NIC {0} {1} Driver={2} {3}" -f $n.Name,$n.Model,$drv,$ver
                  $class='NIC'; $status='Unknown'; $note='no rule'
                  foreach($rule in $io){ $hit=$false; if($rule.class -and $rule.class -ne $class){ continue }; if($rule.match -and ($n.Model -like ("*"+$rule.match+"*"))){ $hit=$true } elseif(-not $hit -and $rule.vid -and $rule.did){ $pciEnt=$null; try { $pciEnt = $pci | Where-Object { $_.DeviceAddress -eq $n.Pci } | Select-Object -First 1 } catch {}; if($pciEnt){ $v=($pciEnt.VendorID -replace '^0x','').ToLower(); $d=($pciEnt.DeviceID -replace '^0x','').ToLower(); if($v -eq $rule.vid.ToLower() -and $d -eq $rule.did.ToLower()){ $hit=$true } } }; if($hit){ $supported=$false; if($rule.esxi -contains $EsxTarget){ $supported=$true }; if ($supported) { $status='Pass' } else { $status='Fail' }; if($rule.driver -and $rule.driver.name){ if($drv -and ($drv.ToLower() -eq $rule.driver.name.ToLower())){ if($rule.driver.min){ if((Compare-Version $ver $rule.driver.min) -lt 0){ $status='Fail'; $note='driver<min' } } } else { $status='Fail'; $note='driver!=rule' } }; break } }
                  if ($note -and $note -ne 'no rule') { $detail = $detail + "; Note=" + $note }
                  $rows.Add([pscustomobject]@{Host=$TargetHost;Check='IO BCG';Status=$status;Detail=$detail}) | Out-Null
                }

                foreach($h in $hbas){
                  $drv=$h.Driver; $ver= if($drv -and $drvVer.ContainsKey($drv.ToLower())){ $drvVer[$drv.ToLower()] } else { '' }
                  $detail = "HBA {0} {1} Driver={2} {3}" -f $h.Name,$h.Model,$drv,$ver
                  $class='HBA'; $status='Unknown'; $note='no rule'
                  foreach($rule in $io){ $hit=$false; if($rule.class -and $rule.class -ne $class){ continue }; if($rule.match -and ($h.Model -like ("*"+$rule.match+"*"))){ $hit=$true } elseif(-not $hit -and $rule.vid -and $rule.did){ $pciEnt=$null; try { $pciEnt = $pci | Where-Object { $_.DeviceAddress -eq $h.Pci } | Select-Object -First 1 } catch {}; if($pciEnt){ $v=($pciEnt.VendorID -replace '^0x','').ToLower(); $d=($pciEnt.DeviceID -replace '^0x','').ToLower(); if($v -eq $rule.vid.ToLower() -and $d -eq $rule.did.ToLower()){ $hit=$true } } }; if($hit){ $supported=$false; if($rule.esxi -contains $EsxTarget){ $supported=$true }; if ($supported) { $status='Pass' } else { $status='Fail' }; if($rule.driver -and $rule.driver.name){ if($drv -and ($drv.ToLower() -eq $rule.driver.name.ToLower())){ if($rule.driver.min){ if((Compare-Version $ver $rule.driver.min) -lt 0){ $status='Fail'; $note='driver<min' } } } else { $status='Fail'; $note='driver!=rule' } }; break } }
                  if ($note -and $note -ne 'no rule') { $detail = $detail + "; Note=" + $note }
                  $rows.Add([pscustomobject]@{Host=$TargetHost;Check='IO BCG';Status=$status;Detail=$detail}) | Out-Null
                }
              } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='IO BCG';Status='Unknown';Detail=$_.Exception.Message}) | Out-Null }
            } else { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='IO BCG';Status='Unknown';Detail='bcg_io.json not found'}) | Out-Null }
          }

          # SSD BCG
          if ($UseBCG) { if ($BcgSsdRaw) {
            try { $ssdMap=Load-CompatRules $BcgSsdRaw; $cli3=Get-EsxCli -VMHost $vmh -V2; $devs=$null; try { $devs = $cli3.storage.core.device.list.Invoke() } catch {}; foreach($d in ($devs | Where-Object { $_ -and $_.IsSsd -eq $true })) { $model = if($d.Model){ $d.Model } elseif($d.DisplayName){ $d.DisplayName } else { $null }; if(-not $model){ continue }; $m=$null; foreach($e in $ssdMap){ if($e.match -and ($model -like ("*"+$e.match+"*"))){ $m=$e; break } }; if($m){ $ok=$false; if ($m.esxi -contains $EsxTarget){ $ok=$true }; $status='Fail'; if($ok){ $status='Pass' }; $rows.Add([pscustomobject]@{Host=$TargetHost;Check='SSD BCG';Status=$status;Detail=("Model={0}; Match={1}; Supports=[{2}]" -f $model,$m.match,($m.esxi -join ','))}) } } } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='SSD BCG';Status='Unknown';Detail=$_.Exception.Message}) | Out-Null } } else { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='SSD BCG';Status='Unknown';Detail='bcg_ssd.json not found'}) | Out-Null } }

          # Neighbor clarity (VSS vs VDS, discovery)
          try {
            $netRef = $vmh.ExtensionData.ConfigManager.NetworkSystem
            if (-not $netRef) { throw "No NetworkSystem for host" }
            $net = Get-View $netRef
            if (-not $net -or -not $net.NetworkInfo -or -not $net.NetworkInfo.Pnic) { throw "No physical NIC info" }
            $pn  = $net.NetworkInfo.Pnic
            $vss = Get-VirtualSwitch -VMHost $vmh -Standard -EA SilentlyContinue
            $vds = Get-VDSwitch     -VMHost $vmh -EA SilentlyContinue
            $dvMap = @{}
            foreach($dvs in $vds){ try { $upl = Get-VMHostNetworkAdapter -VMHost $vmh -Physical -DistributedSwitch $dvs -EA SilentlyContinue; foreach($u in $upl){ $dvMap[$u.DeviceName] = $dvs } } catch {} }
            foreach($p in $pn){
              $vsName = $null; $isVss=$false; $isVds=$false; $cdpStatus=$null; $ldpProto=$null; $ldpOp=$null
              $vs = ($vss | Where-Object { $_.Nic -contains $p.Device } | Select-Object -First 1)
              if($vs){ $isVss=$true; $vsName=$vs.Name; $cdpStatus=$vs.CDPStatus }
              elseif($dvMap.ContainsKey($p.Device)){
                $isVds=$true; $vsName = $dvMap[$p.Device].Name; $ldpProto = $dvMap[$p.Device].LinkDiscoveryProtocol; $ldpOp = $dvMap[$p.Device].LinkDiscoveryProtocolOperation
              }

              $hint = $net.QueryNetworkHint($p.Device)
              if($hint -and $hint.ConnectedSwitchPort){
                $c=$hint.ConnectedSwitchPort
                $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Neighbor';Status='CDP';Detail=("vmnic={0}; vSwitch={1}; Switch={2}; PortId={3}; MgmtAddr={4}; Platform={5}" -f $p.Device,$vsName,$c.DevId,$c.PortId,$c.MgmtAddr,$c.HardwarePlatform)}) | Out-Null
              } elseif($hint -and $hint.LLDPInfo){
                $sys  = ($hint.LLDPInfo.Parameter | Where-Object {$_.Key -eq 'System Name'} | Select-Object -ExpandProperty Value -First 1)
                $port = ($hint.LLDPInfo.Parameter | Where-Object {$_.Key -in 'Port Description','Port ID'} | Select-Object -ExpandProperty Value -First 1)
                $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Neighbor';Status='LLDP';Detail=("vmnic={0}; vSwitch={1}; Switch={2}; Port={3}" -f $p.Device,$vsName,$sys,$port)}) | Out-Null
              } else {
                if ($isVss) {
                  $why = 'VSS uplink: ESXi supports CDP only; LLDP not available on VSS. If upstream speaks LLDP-only, no neighbor will appear.'
                  if ($cdpStatus) { $why += (" CDP status={0}." -f $cdpStatus) }
                  $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Neighbor';Status='None';Detail=("vmnic={0}; vSwitch={1}; {2}" -f $p.Device,$vsName,$why)}) | Out-Null
                } elseif ($isVds) {
                  $why = 'No discovery data.'
                  if ($ldpProto -and $ldpOp) { $why = ("VDS uplink: {0}/{1}; if set to None, enable Listen/Advertise to see neighbors." -f $ldpProto,$ldpOp) }
                  $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Neighbor';Status='None';Detail=("vmnic={0}; vSwitch={1}; {2}" -f $p.Device,$vsName,$why)}) | Out-Null
                } else {
                  $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Neighbor';Status='None';Detail=("vmnic={0}; vSwitch=; No discovery data (uplink not mapped to VSS/VDS)" -f $p.Device)}) | Out-Null
                }
              }
            }
          } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Neighbor';Status='Unknown';Detail=$_.Exception.Message}) | Out-Null }

        } finally { try { if($vi){ Disconnect-VIServer -Server $vi -Force -Confirm:$false -EA SilentlyContinue | Out-Null } } catch {} }
      } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Error';Status='Fail';Detail=$_.Exception.Message}) | Out-Null }
      $rows
    }
    [void]$script:RunJobs.Add($job)
  }

  while($script:RunJobs.Where({ $_.State -in 'Running','NotStarted' }).Count){ Start-Sleep -Milliseconds 150; Do-Events }
  foreach($j in @($script:RunJobs)){
    try { $res = Receive-Job -Job $j -ErrorAction SilentlyContinue; if($res){ foreach($r in $res){ $script:Rows.Add($r) | Out-Null }; $script:gridResults.Items.Refresh() } }
    catch { Write-Log ("Run job error: {0}" -f $_.Exception.Message) 'ERROR' }
    finally { try { Remove-Job -Job $j -Force -EA SilentlyContinue } catch {}; [void]$script:RunJobs.Remove($j) }
  }

  # Outputs
  $csv = Join-Path $script:RunDir 'PerHostRows.csv'
  $script:Rows | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
  Write-Log ("CSV saved: {0}" -f $csv)

  if (Has-Module 'ImportExcel') {
    try { Try-Import 'ImportExcel' | Out-Null; $xlsx = Join-Path $script:RunDir ("VCF9-ESXi-Readiness-" + (Get-Date -Format 'yyyyMMdd-HHmmss') + ".xlsx"); $script:Rows | Export-Excel -Path $xlsx -WorksheetName 'HostRows' -TableName 'HostRows' -AutoSize -FreezeTopRow; $neighbors = $script:Rows | Where-Object { $_.Check -eq 'Neighbor' }; if($neighbors){ $neighbors | Export-Excel -Path $xlsx -WorksheetName 'Neighbors' -AutoSize -FreezeTopRow -Append }; Write-Log ("Excel saved: {0}" -f $xlsx) } catch { Write-Log ("Excel export failed: {0}" -f $_.Exception.Message) 'WARN' }
  } else { Write-Log "ImportExcel not installed — skipping Excel output." 'WARN' }
  Enable-RunButtons $true
} 'btnRun' })

# Cancel
$script:btnCancel.Add_Click({ Try-Do {
  if ($script:RunJobs.Count -gt 0) {
    Write-Log ("Cancel requested. Stopping {0} job(s)..." -f $script:RunJobs.Count) 'WARN'
    foreach($j in @($script:RunJobs)){ try { if ($j.State -in 'Running','NotStarted'){ Stop-Job -Job $j -Force -EA SilentlyContinue } } catch{} }
    Start-Sleep -Milliseconds 250
    foreach($j in @($script:RunJobs)){ try { Remove-Job -Job $j -Force -EA SilentlyContinue } catch{}; [void]$script:RunJobs.Remove($j) }
    Write-Log "All running jobs stopped." 'WARN'
  }
} 'btnCancel' })

# Show UI
try {
  Write-Host ('[DBG ] Final STA={0}' -f [Threading.Thread]::CurrentThread.ApartmentState)
  try { Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase -ErrorAction SilentlyContinue | Out-Null } catch {}
  if (-not $script:window) { Write-Host '[DBG ] $script:window null — reparsing'; $script:window = [Windows.Markup.XamlReader]::Parse($xaml) }
  try { if (Get-Command Prereq-Check -ErrorAction SilentlyContinue) { $null = $script:window.Add_ContentRendered({ try { Prereq-Check | Out-Null } catch {} }) } } catch {}
  Write-Host '[DBG ] Showing window (ShowDialog)'
  $null = $script:window.ShowDialog()
  Write-Host '[DBG ] Window closed'
} catch { Write-Host ("[ERR ] Final ShowDialog failed: {0}" -f $_.Exception.Message); throw }

# SIG # Begin signature block
# MIId3wYJKoZIhvcNAQcCoIId0DCCHcwCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCCng4J8gW3zCN3
# jHMFSkug7fhiHqA55j20lKYhiARSdqCCF4gwggRKMIICsqADAgECAhBUZ6AKJOtZ
# hET4y/4hrL7fMA0GCSqGSIb3DQEBCwUAMD0xOzA5BgNVBAMMMlZDRjkgUmVhZGlu
# ZXNzIExvY2FsIENvZGUgU2lnbmluZyAoeGFkbWluQEhPTUVMQUIpMB4XDTI1MTEw
# NjIyMDkzM1oXDTMwMTEwNjIyMTkzMlowPTE7MDkGA1UEAwwyVkNGOSBSZWFkaW5l
# c3MgTG9jYWwgQ29kZSBTaWduaW5nICh4YWRtaW5ASE9NRUxBQikwggGiMA0GCSqG
# SIb3DQEBAQUAA4IBjwAwggGKAoIBgQDhmO0QQGKZslnwXHD1xafSAUErzW8Cf4PP
# 33DPNw5+ftKCHD3FLbQdnKiW+Vs5g20zPVfeVsp0Yw7ixteW/jB7F+wSfWJuvAUU
# UxRa6uyGTf2lAaPuW7wRNjjAswMhRHh58xmDTelSBqoHzLDKqPeEkbuBdMfyWsrk
# 2bTLBQvU9PDXpkMoD4qP0g2YOfACTRAtGbojtNWFXdRqs8h5ICjfqQrBdWbU+EJJ
# i3ITSRrtXYTB+rWZaX4IFurMhazkF6LZ9iynz9hT3I0qEJnX/f2zkayz7rX9TfNQ
# WrlBjh0mLur4UmhMeDBmKnLAO3B5RuUvBjpagnXUEYUtyE7hrjRyC2+rijzNkWkk
# jm2cVmIijYxxLBdn7V83TYlhaxmUzXloKKmLLf6hYSenuWp05/1nwT1S+2dZGqzV
# LopqHMTSPpbA0VNbuAzvS3Ymb7TTZ9J73ErBXXe/BmuuM5VVEV/LinDCWbRR18wx
# f6lOzCllIJmB/rg48kMI5AZ6RovejvkCAwEAAaNGMEQwDgYDVR0PAQH/BAQDAgeA
# MBMGA1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSNZ1dKfBFqRk0PdDcYpwc5
# AOzJrTANBgkqhkiG9w0BAQsFAAOCAYEA2L7g7iSpo0tjuGb7MmAw0JRHT49cpIbC
# 5i+DHjaI0VvCq9X8EuwOYufsILETLzv12aSUpyJVzZqhg71gXaUb2tzc1EKSS41f
# 0zNpsud1nt+mMdyLUQvwdUIebSgSQdoMSxENBs6UlePLoR/HlL6jSDmjeHK/NJDW
# xbRi2CPybCwJ/i56lyuoPwEWG7wKDBpTPtQ+8wzgZGjPe0bjGthd/qrauvLPq0cI
# Q7FD4tI9eNFeFS8KOb/g7a2XJwLn1w/ed9HgJf8XDecSlUmzToOgIH4WvkeajUsn
# nrdouEAfP44uUmxLuOHuqWU1krkZWBFscN5d1JOaPmhv/2q3/HtnGxMDI7Nwvj2q
# 74PlsTxb/iiOuiv2VIFefiMWrQ5eLbpqrCqBaBQSJ83laLEVdxH7qexWd7P1y4iW
# 2DLG58A4GXfCipDtU0ZI+o83p4im2yEHUl43o4wsHDo7iRYzicAeE19B+Bo2RYgL
# r3GM7bGRmf1Zs5V5iCoVNJFAq8JqCOzkMIIFjTCCBHWgAwIBAgIQDpsYjvnQLefv
# 21DiCEAYWjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQD
# ExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAxMDAwMDAwWhcN
# MzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQg
# SW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2Vy
# dCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aaza57G4QNxDAf
# 8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllVcq9ok3DCsrp1
# mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT+CFhmzTrBcZe
# 7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd463JT17lNecx
# y9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+EJFwq1WCQTLX
# 2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92kJ7yhTzm1EVgX
# 9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5jrubU75KSOp49
# 3ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7f/LVjHAsQWCq
# sWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJUKSWJbOUOUlFH
# dL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+whX8QgUWtvsauG
# i0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQABo4IBOjCCATYw
# DwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5nP+e6mK4cD08w
# HwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0PAQH/BAQDAgGG
# MHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDwwOqA4oDaGNGh0
# dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5j
# cmwwEQYDVR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IBAQBwoL9DXFXn
# OF+go3QbPbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229GhT0E0p6Ly23
# OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FDRJtDIeuWcqFI
# tJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVGamlUsLihVo7s
# pNU96LHc/RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCwrFigDkBjxZgi
# wbJZ9VVrzyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvRXKwYw02fc7cB
# qZ9Xql4o4rmUMIIGtDCCBJygAwIBAgIQDcesVwX/IZkuQEMiDDpJhjANBgkqhkiG
# 9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkw
# FwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVz
# dGVkIFJvb3QgRzQwHhcNMjUwNTA3MDAwMDAwWhcNMzgwMTE0MjM1OTU5WjBpMQsw
# CQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERp
# Z2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hBMjU2IDIw
# MjUgQ0ExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAtHgx0wqYQXK+
# PEbAHKx126NGaHS0URedTa2NDZS1mZaDLFTtQ2oRjzUXMmxCqvkbsDpz4aH+qbxe
# Lho8I6jY3xL1IusLopuW2qftJYJaDNs1+JH7Z+QdSKWM06qchUP+AbdJgMQB3h2D
# Z0Mal5kYp77jYMVQXSZH++0trj6Ao+xh/AS7sQRuQL37QXbDhAktVJMQbzIBHYJB
# YgzWIjk8eDrYhXDEpKk7RdoX0M980EpLtlrNyHw0Xm+nt5pnYJU3Gmq6bNMI1I7G
# b5IBZK4ivbVCiZv7PNBYqHEpNVWC2ZQ8BbfnFRQVESYOszFI2Wv82wnJRfN20VRS
# 3hpLgIR4hjzL0hpoYGk81coWJ+KdPvMvaB0WkE/2qHxJ0ucS638ZxqU14lDnki7C
# coKCz6eum5A19WZQHkqUJfdkDjHkccpL6uoG8pbF0LJAQQZxst7VvwDDjAmSFTUm
# s+wV/FbWBqi7fTJnjq3hj0XbQcd8hjj/q8d6ylgxCZSKi17yVp2NL+cnT6Toy+rN
# +nM8M7LnLqCrO2JP3oW//1sfuZDKiDEb1AQ8es9Xr/u6bDTnYCTKIsDq1BtmXUqE
# G1NqzJKS4kOmxkYp2WyODi7vQTCBZtVFJfVZ3j7OgWmnhFr4yUozZtqgPrHRVHhG
# NKlYzyjlroPxul+bgIspzOwbtmsgY1MCAwEAAaOCAV0wggFZMBIGA1UdEwEB/wQI
# MAYBAf8CAQAwHQYDVR0OBBYEFO9vU0rp5AZ8esrikFb2L9RJ7MtOMB8GA1UdIwQY
# MBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUE
# DDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGGGGh0dHA6
# Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2NhY2VydHMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYDVR0fBDww
# OjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3Rl
# ZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMA0G
# CSqGSIb3DQEBCwUAA4ICAQAXzvsWgBz+Bz0RdnEwvb4LyLU0pn/N0IfFiBowf0/D
# m1wGc/Do7oVMY2mhXZXjDNJQa8j00DNqhCT3t+s8G0iP5kvN2n7Jd2E4/iEIUBO4
# 1P5F448rSYJ59Ib61eoalhnd6ywFLerycvZTAz40y8S4F3/a+Z1jEMK/DMm/axFS
# goR8n6c3nuZB9BfBwAQYK9FHaoq2e26MHvVY9gCDA/JYsq7pGdogP8HRtrYfctSL
# ANEBfHU16r3J05qX3kId+ZOczgj5kjatVB+NdADVZKON/gnZruMvNYY2o1f4MXRJ
# DMdTSlOLh0HCn2cQLwQCqjFbqrXuvTPSegOOzr4EWj7PtspIHBldNE2K9i697cva
# iIo2p61Ed2p8xMJb82Yosn0z4y25xUbI7GIN/TpVfHIqQ6Ku/qjTY6hc3hsXMrS+
# U0yy+GWqAXam4ToWd2UQ1KYT70kZjE4YtL8Pbzg0c1ugMZyZZd/BdHLiRu7hAWE6
# bTEm4XYRkA6Tl4KSFLFk43esaUeqGkH/wyW4N7OigizwJWeukcyIPbAvjSabnf7+
# Pu0VrFgoiovRDiyx3zEdmcif/sYQsfch28bZeUz2rtY/9TCA6TD8dC3JE3rYkrhL
# ULy7Dc90G6e8BlqmyIjlgp2+VqsS9/wQD7yFylIz0scmbKvFoW2jNrbM1pD2T7m3
# XDCCBu0wggTVoAMCAQICEAqA7xhLjfEFgtHEdqeVdGgwDQYJKoZIhvcNAQELBQAw
# aTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEwPwYDVQQD
# EzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVTdGFtcGluZyBSU0E0MDk2IFNIQTI1
# NiAyMDI1IENBMTAeFw0yNTA2MDQwMDAwMDBaFw0zNjA5MDMyMzU5NTlaMGMxCzAJ
# BgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGln
# aUNlcnQgU0hBMjU2IFJTQTQwOTYgVGltZXN0YW1wIFJlc3BvbmRlciAyMDI1IDEw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDQRqwtEsae0OquYFazK1e6
# b1H/hnAKAd/KN8wZQjBjMqiZ3xTWcfsLwOvRxUwXcGx8AUjni6bz52fGTfr6PHRN
# v6T7zsf1Y/E3IU8kgNkeECqVQ+3bzWYesFtkepErvUSbf+EIYLkrLKd6qJnuzK8V
# cn0DvbDMemQFoxQ2Dsw4vEjoT1FpS54dNApZfKY61HAldytxNM89PZXUP/5wWWUR
# K+IfxiOg8W9lKMqzdIo7VA1R0V3Zp3DjjANwqAf4lEkTlCDQ0/fKJLKLkzGBTpx6
# EYevvOi7XOc4zyh1uSqgr6UnbksIcFJqLbkIXIPbcNmA98Oskkkrvt6lPAw/p4oD
# SRZreiwB7x9ykrjS6GS3NR39iTTFS+ENTqW8m6THuOmHHjQNC3zbJ6nJ6SXiLSvw
# 4Smz8U07hqF+8CTXaETkVWz0dVVZw7knh1WZXOLHgDvundrAtuvz0D3T+dYaNcwa
# fsVCGZKUhQPL1naFKBy1p6llN3QgshRta6Eq4B40h5avMcpi54wm0i2ePZD5pPIs
# soszQyF4//3DoK2O65Uck5Wggn8O2klETsJ7u8xEehGifgJYi+6I03UuT1j7Fnrq
# VrOzaQoVJOeeStPeldYRNMmSF3voIgMFtNGh86w3ISHNm0IaadCKCkUe2LnwJKa8
# TIlwCUNVwppwn4D3/Pt5pwIDAQABo4IBlTCCAZEwDAYDVR0TAQH/BAIwADAdBgNV
# HQ4EFgQU5Dv88jHt/f3X85FxYxlQQ89hjOgwHwYDVR0jBBgwFoAU729TSunkBnx6
# yuKQVvYv1Ensy04wDgYDVR0PAQH/BAQDAgeAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMIGVBggrBgEFBQcBAQSBiDCBhTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3Au
# ZGlnaWNlcnQuY29tMF0GCCsGAQUFBzAChlFodHRwOi8vY2FjZXJ0cy5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRUcnVzdGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hBMjU2
# MjAyNUNBMS5jcnQwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDovL2NybDMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0VGltZVN0YW1waW5nUlNBNDA5NlNIQTI1
# NjIwMjVDQTEuY3JsMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATAN
# BgkqhkiG9w0BAQsFAAOCAgEAZSqt8RwnBLmuYEHs0QhEnmNAciH45PYiT9s1i6UK
# tW+FERp8FgXRGQ/YAavXzWjZhY+hIfP2JkQ38U+wtJPBVBajYfrbIYG+Dui4I4PC
# vHpQuPqFgqp1PzC/ZRX4pvP/ciZmUnthfAEP1HShTrY+2DE5qjzvZs7JIIgt0GCF
# D9ktx0LxxtRQ7vllKluHWiKk6FxRPyUPxAAYH2Vy1lNM4kzekd8oEARzFAWgeW3a
# z2xejEWLNN4eKGxDJ8WDl/FQUSntbjZ80FU3i54tpx5F/0Kr15zW/mJAxZMVBrTE
# 2oi0fcI8VMbtoRAmaaslNXdCG1+lqvP4FbrQ6IwSBXkZagHLhFU9HCrG/syTRLLh
# Aezu/3Lr00GrJzPQFnCEH1Y58678IgmfORBPC1JKkYaEt2OdDh4GmO0/5cHelAK2
# /gTlQJINqDr6JfwyYHXSd+V08X1JUPvB4ILfJdmL+66Gp3CSBXG6IwXMZUXBhtCy
# Iaehr0XkBoDIGMUG1dUtwq1qmcwbdUfcSYCn+OwncVUXf53VJUNOaMWMts0VlRYx
# e5nK+At+DI96HAlXHAL5SlfYxJ7La54i71McVWRP66bW+yERNpbJCjyCYG2j+bdp
# xo/1Cy4uPcU3AWVPGrbn5PhDBf3Froguzzhk++ami+r3Qrx5bIbY3TVzgiFI7Gq3
# zWcxggWtMIIFqQIBATBRMD0xOzA5BgNVBAMMMlZDRjkgUmVhZGluZXNzIExvY2Fs
# IENvZGUgU2lnbmluZyAoeGFkbWluQEhPTUVMQUIpAhBUZ6AKJOtZhET4y/4hrL7f
# MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJ
# KoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQB
# gjcCARUwLwYJKoZIhvcNAQkEMSIEIPey0Ws8nF1y+FrLFJLayYSxkpTptVgCn/Uf
# 7mLh/SmLMA0GCSqGSIb3DQEBAQUABIIBgK8anQQYMJQaxXwhVs6AeV4w5Y9fInwd
# bTxTH39bv3of+BGpR3J4bxCxq5qSKhvIubPleH71naj0aPtJbEcAB28BU7tnNUFu
# HU6ygI/rH4URHmecMFYvmWNNhuH9tL0W/lPWQ2YI35KQH/1r++jEeLg5xaOybi1m
# 5+AGuwQLtBl7zsAILWTpjsjB/LQlrTd3ICWa1jahwTaNjXwLL+aY8R6FVs+ISdll
# r4OgitM1yTZl3pmlFqkGAKV0bTck/xmcODMFeGq5VLwkuZpk9QXxll++hmc9aux7
# 0FBFNaG+eY0fiy8j7uE8EqHzL0aFN3QqcmlDggyFLdmsopImmzKU5DR6WqfJBCZi
# lPrjxUryCevn1hicml9BbIJsfGHZJzplWYZUKiFgFmLURYM2RUJTa+eXiwlIEXAv
# pZ2yVsyRGFkpn5MKkT6EbDT3nL491AiJVoetxcW7PelIOVOdSQsw8xahwehM1LIl
# xShwhhmvR7u1ldivo+sFdCrLYhmgJN/ctqGCAyYwggMiBgkqhkiG9w0BCQYxggMT
# MIIDDwIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5j
# LjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcgUlNB
# NDA5NiBTSEEyNTYgMjAyNSBDQTECEAqA7xhLjfEFgtHEdqeVdGgwDQYJYIZIAWUD
# BAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEP
# Fw0yNTExMDcxOTQ2MzNaMC8GCSqGSIb3DQEJBDEiBCBbFGVrXvoosi43KgEB1TBx
# rZ1hwZxd8PUeskazY4+1jTANBgkqhkiG9w0BAQEFAASCAgCaxnfiogXY/sJSwx9t
# lU99OvpAzkr40OLitebGdLz6ghSN326hB+i4UrH+z4BxBWLbD3NyQmqbDJt017Ew
# XI7hFy9nqcq1PsTXT/jyEbZ/m/D4utSbEMuceL4AJWR37BiUZA1IPtI/8WupdqgW
# 9KKbby2H04JxHvL/8Of06ErY9OQtU2rYW8ARJZS9QjK8cYSu6hC5b1w98g6oOF1A
# owIf3wNUzepxDN2HM/BGq7RcY5TbpDayPaV/D1HU4uQQXhnmIdIXuKtEm+cbXefH
# d+mmJXEXOgftQvS29Swsuek6bmC7ULoywhOaMhxZPRZ6B3vP35UZKtHrMfPmv4sI
# RubdL+dRWIB8zn8ZQ+QgLqR9V0njrQGeKJRT8qbHhcTl/KN7DV9/QOwhbaikc9v8
# zOcrxY1xj8ZoFPK+O/ItNfGGc1kZY9MCxZN3YUG1kDK+53M3yfwrY6QJGLYhTD7X
# oRl3/4NoBL/+c/qbWvhwNvuHHRUb9vI4l//Q3WCwkFFm6JspX9fO8Q7SBG2aMa3l
# vmPXeItgrlv+/sZrlE6tzOVEDlCTGz6JF6stxw9DmeFV+InPlPh2CarjIui82zOj
# kCwwhiQuSqq3C9ALsQfMfwdY23GtfS2Pw9aarA7mGHML3OzEUlRLWXO22u+NhiXU
# 32vafI1HCfYKy6ohLGRjVcKCNQ==
# SIG # End signature block
