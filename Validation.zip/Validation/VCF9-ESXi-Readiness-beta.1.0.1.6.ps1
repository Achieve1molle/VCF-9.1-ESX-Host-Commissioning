# VCF9-ESXi-Readiness-r6i6.ps1
# r6i UI + auto self-sign on normal launch (no flags) + exact r6i visuals + functional upgrades

[CmdletBinding()]
param(
    [switch]$NoRelaunch,
    [switch]$SignedOk,
    [switch]$NoAutoSign
)



$VerbosePreference       = 'SilentlyContinue'
$ProgressPreference      = 'SilentlyContinue'
$InformationPreference   = 'Continue'
$ErrorActionPreference   = 'Stop'

# --- Self-sign (in place; auto-relaunch; no temp files) -----------------------

# --- One-time self-sign + relaunch (trusted signer + STA) -------------------------------
function Ensure-SelfSigned {
    param([Parameter(Mandatory)][string]$TargetPath)
    try { $sig = Get-AuthenticodeSignature -FilePath $TargetPath -ErrorAction SilentlyContinue } catch { $sig = $null }
    if ($sig -and $sig.Status -eq 'Valid') { return $false }
    Write-Host "[SelfSign] Creating/trusting local code-signing cert and signing the script..."
    $subject = "CN=VCF9 Readiness Local Code Signing ($env:USERNAME@$env:COMPUTERNAME)"
    $cert = Get-ChildItem -Path Cert:\CurrentUser\My -CodeSigningCert -ErrorAction SilentlyContinue |
            Where-Object { $_.Subject -like "CN=VCF9 Readiness Local Code Signing*" } |
            Sort-Object NotAfter -Descending | Select-Object -First 1
    if (-not $cert) {
        $cert = New-SelfSignedCertificate -Type CodeSigningCert `
                 -Subject $subject -CertStoreLocation 'Cert:\CurrentUser\My' `
                 -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 `
                 -KeyExportPolicy Exportable -NotAfter (Get-Date).AddYears(5)
    }
    try { $null = $cert | Copy-Item -Destination 'Cert:\CurrentUser\Root' -Force -ErrorAction SilentlyContinue } catch {}
    try { $null = $cert | Copy-Item -Destination 'Cert:\CurrentUser\TrustedPublisher' -Force -ErrorAction SilentlyContinue } catch {}
    try {
        try { Set-AuthenticodeSignature -FilePath $TargetPath -Certificate $cert -HashAlgorithm SHA256 -TimestampServer 'http://timestamp.digicert.com' -ErrorAction Stop | Out-Null }
        catch { Set-AuthenticodeSignature -FilePath $TargetPath -Certificate $cert -HashAlgorithm SHA256 -ErrorAction Stop | Out-Null }
        Write-Host "[SelfSign] Script signed."; return $true
    } catch { Write-Host "[WARN ] Self-sign failed: $($_.Exception.Message)"; return $false }
}

try { $pwsh = (Get-Process -Id $PID).Path } catch { $pwsh = $null }
if (-not $pwsh) { $pwsh = (Get-Command pwsh -ErrorAction SilentlyContinue)?.Source }
if (-not $pwsh) { $pwsh = Join-Path $PSHOME 'pwsh.exe' }

if (-not $NoAutoSign -and -not $SignedOk) {
    $didSign = Ensure-SelfSigned -TargetPath $PSCommandPath
    if ($didSign) { & $pwsh -NoProfile -ExecutionPolicy Bypass -STA -File "$PSCommandPath" -SignedOk -NoRelaunch; exit $LASTEXITCODE }
    else { Write-Host "[WARN ] Proceeding unsigned (self-sign not available)." }
}

if (-not $NoRelaunch) {
    if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
        & $pwsh -NoProfile -ExecutionPolicy Bypass -STA -File "$PSCommandPath" -NoRelaunch -SignedOk
        exit $LASTEXITCODE
    }
}
# --- Paths & run folder --------------------------------------------------------
$script:ScriptBase = Split-Path -Parent $PSCommandPath
$script:RunBase    = (Get-Location).Path
$script:RunDir     = Join-Path $script:RunBase ("VCF9-Readiness-Run-" + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$null = New-Item -ItemType Directory -Path $script:RunDir -Force | Out-Null

$Global:LogFile = Join-Path $script:RunDir ("Readiness-" + (Get-Date -Format 'yyyyMMdd-HHmmss') + ".log")
"" | Out-File $Global:LogFile -Encoding UTF8 -Force

function Write-Log {
  param([Parameter(Mandatory)][string]$Message,
        [ValidateSet('INFO','WARN','ERROR')][string]$Level='INFO')
  $ts   = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff')
  $line = "[$ts][$Level] $Message"
  try { Add-Content -Path $Global:LogFile -Value $line -Encoding UTF8 -EA SilentlyContinue } catch {}
  try {
    if ($script:txtLog -and $script:txtLog.Dispatcher -and -not $script:txtLog.Dispatcher.HasShutdownStarted) {
      $null = $script:txtLog.Dispatcher.Invoke([Action]{ $script:txtLog.AppendText($line + "`r`n"); $script:txtLog.ScrollToEnd() })
    }
  } catch {}
  Write-Host $line
}
Write-Log "Script start (r6i6)"

if ($PSVersionTable.PSVersion.Major -lt 7) {
  Write-Log "PowerShell 7+ required. Found: $($PSVersionTable.PSVersion)" 'ERROR'
  throw "PowerShell 7+ required."
}

# --- UI (r6i layout; combobox height 26px to match buttons) -------------------
try {
  Add-Type -AssemblyName PresentationCore,PresentationFramework,WindowsBase | Out-Null
  Add-Type -AssemblyName System.Windows.Forms | Out-Null
} catch {
  Write-Log ("WPF assembly load failed: {0}" -f $_.Exception.Message) 'ERROR'
  throw
}

$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Achieve One—Leadership to Adapt—Expertise to Achieve" Height="900" Width="1480"
        WindowStartupLocation="CenterScreen" Background="#0F0F10" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="12">
  <Window.Resources>
    <SolidColorBrush x:Key="WinBg"     Color="#0F0F10"/>
    <SolidColorBrush x:Key="PanelBg"   Color="#171819"/>
    <SolidColorBrush x:Key="BorderBr"  Color="#2E2F31"/>
    <SolidColorBrush x:Key="GridBg"    Color="#1B1C1E"/>
    <SolidColorBrush x:Key="GridBgAlt" Color="#1C1E21"/>
    <SolidColorBrush x:Key="LogBg"     Color="#0E0F10"/>

    <Style TargetType="GroupBox">
      <Setter Property="Background" Value="{StaticResource PanelBg}"/>
      <Setter Property="BorderBrush" Value="{StaticResource BorderBr}"/>
      <Setter Property="Margin" Value="8,6,8,8"/>
      <Setter Property="Padding" Value="4"/>
      <Setter Property="Foreground" Value="#FFFFFF"/>
    </Style>
    <Style TargetType="Button">
      <Setter Property="Padding" Value="14,8"/>
      <Setter Property="Margin" Value="6,0,0,6"/>
      <Setter Property="MinWidth" Value="180"/>
      <Setter Property="Width" Value="180"/>
      <Setter Property="HorizontalAlignment" Value="Left"/>
    </Style>
    <Style TargetType="TextBox">
      <Setter Property="Padding" Value="6,4"/>
      <Setter Property="Background" Value="#131415"/>
      <Setter Property="BorderBrush" Value="{StaticResource BorderBr}"/>
      <Setter Property="Foreground" Value="#FFFFFF"/>
    </Style>
    <Style TargetType="DataGrid">
      <Setter Property="Background" Value="{StaticResource GridBg}"/>
      <Setter Property="Foreground" Value="#FFFFFF"/>
      <Setter Property="BorderBrush" Value="{StaticResource BorderBr}"/>
      <Setter Property="RowHeight" Value="24"/>
      <Setter Property="ColumnHeaderHeight" Value="26"/>
      <Setter Property="HeadersVisibility" Value="Column"/>
      <Setter Property="GridLinesVisibility" Value="None"/>
      <Setter Property="AlternatingRowBackground" Value="{StaticResource GridBgAlt}"/>
    </Style>
    <Style TargetType="DataGridColumnHeader">
      <Setter Property="Background" Value="#202225"/>
      <Setter Property="Foreground" Value="#FFFFFF"/>
      <Setter Property="BorderBrush" Value="{StaticResource BorderBr}"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
    </Style>
    <Style TargetType="DataGridCell">
      <Setter Property="Background" Value="{StaticResource GridBg}"/>
      <Setter Property="Foreground" Value="#FFFFFF"/>
      <Setter Property="BorderBrush" Value="{StaticResource BorderBr}"/>
      <Setter Property="BorderThickness" Value="0,0,1,1"/>
    </Style>
    <!-- CheckBox text white for dark theme -->
    <Style TargetType="CheckBox"><Setter Property="Foreground" Value="#FFFFFF"/></Style>

    <!-- Toolbar ComboBox height matches button -->
    <Style x:Key="ToolbarCombo" TargetType="ComboBox">
      <Setter Property="Height" Value="26"/>
      <Setter Property="MinWidth" Value="160"/>
      <Setter Property="VerticalContentAlignment" Value="Center"/>
      <Setter Property="Padding" Value="6,0,6,0"/>
      <Setter Property="Margin" Value="6,0,0,6"/>
    </Style>
  </Window.Resources>

  <Grid Margin="10" Background="{StaticResource WinBg}">
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
      <RowDefinition Height="0.9*"/>
      <RowDefinition Height="Auto"/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
      <ColumnDefinition Width="3*"/>
      <ColumnDefinition Width="2*"/>
    </Grid.ColumnDefinitions>

    <!-- Prerequisites -->
    <GroupBox Grid.Row="0" Grid.ColumnSpan="2" Header="Prerequisites">
      <Grid>
        <Grid.ColumnDefinitions>
          <ColumnDefinition Width="*"/>
          <ColumnDefinition Width="*"/>
          <ColumnDefinition Width="Auto"/>
        </Grid.ColumnDefinitions>

        <StackPanel Grid.Column="0" Orientation="Vertical" Margin="6,8,10,4">
          <DockPanel LastChildFill="False" Margin="0,0,0,2"><TextBlock Text="PowerShell:" Margin="0,0,8,0"/><TextBlock x:Name="lblPS" Text="-"/></DockPanel>
          <DockPanel LastChildFill="False" Margin="0,0,0,2"><TextBlock Text="VMware.PowerCLI:" Margin="0,0,8,0"/><TextBlock x:Name="lblPCLI" Text="-"/></DockPanel>
          <DockPanel LastChildFill="False" Margin="0,0,0,2"><TextBlock Text="ImportExcel:" Margin="0,0,8,0"/><TextBlock x:Name="lblExcel" Text="-"/></DockPanel>
          <DockPanel LastChildFill="False" Margin="0,0,0,2"><TextBlock Text="OpenSSH client:" Margin="0,0,8,0"/><TextBlock x:Name="lblOpenSSH" Text="-"/></DockPanel>
          <DockPanel LastChildFill="False" Margin="0,0,0,2"><TextBlock Text="vSAN HCL JSON:" Margin="0,0,8,0"/><TextBlock x:Name="lblVsanJson" Text="-"/></DockPanel>
        </StackPanel>

        <StackPanel Grid.Column="1" Orientation="Vertical" Margin="6,0,10,0" VerticalAlignment="Center">
          <CheckBox x:Name="chkUseBCG"      Content="Enable Broadcom Compatibility Guide (BCG) checks" IsChecked="True"/>
          <CheckBox x:Name="chkUseVSANJson" Content="Use offline vSAN HCL (all.json) if available" IsChecked="True"/>
          <CheckBox x:Name="chkVsanResidue" Content="Check for vSAN residue (fail if found)"/>
        </StackPanel>

        <StackPanel Grid.Column="2" Orientation="Vertical" HorizontalAlignment="Left" Margin="8,0,0,0" VerticalAlignment="Top">
          <Button x:Name="btnInstallPCLI"  Content="Install PowerCLI"/>
          <Button x:Name="btnInstallExcel" Content="Install ImportExcel"/>
          <Button x:Name="btnRecheck"      Content="Recheck"/>
          <Button x:Name="btnGetVsanHcl"   Content="Download vSAN HCL JSON"/>
        </StackPanel>
      </Grid>
    </GroupBox>

    <!-- ESXi Targets -->
    <GroupBox Grid.Row="1" Grid.ColumnSpan="2" Header="ESXi Targets (stand-alone hosts)">
      <DockPanel>
        <StackPanel DockPanel.Dock="Top" Orientation="Horizontal" Margin="6,10,6,10">
          <Button x:Name="btnAdd"     Content="Add Row"/>
          <Button x:Name="btnRemove"  Content="Remove Selected"/>
          <Button x:Name="btnLoad"    Content="Load Targets"/>
          <Button x:Name="btnSave"    Content="Save Targets"/>

          <TextBlock Text="Target ESXi Version:" Margin="24,0,8,0" VerticalAlignment="Center"/>
          <ComboBox x:Name="cmbEsxiTarget" Style="{StaticResource ToolbarCombo}">
            <ComboBoxItem Content="9.0.1.0" IsSelected="True"/>
            <ComboBoxItem Content="9.0.0.1"/>
            <ComboBoxItem Content="8.0 U3"/>
            <ComboBoxItem Content="8.0 U2"/>
            <ComboBoxItem Content="8.0 U1"/>
            <ComboBoxItem Content="8.0"/>
          </ComboBox>
        </StackPanel>

        <DataGrid x:Name="grid" AutoGenerateColumns="False" CanUserAddRows="False" CanUserDeleteRows="True"
                  IsReadOnly="False" Margin="6" MinHeight="300" VerticalAlignment="Stretch">
          <DataGrid.Columns>
            <DataGridTextColumn Header="Host / FQDN" Binding="{Binding TargetHost}" Width="2*"/>
            <DataGridTextColumn Header="Username"    Binding="{Binding Username}"   Width="*"/>
            <DataGridTemplateColumn Header="Password" Width="*">
              <DataGridTemplateColumn.CellTemplate>
                <DataTemplate><PasswordBox Tag="{Binding}" PasswordChar="●"/></DataTemplate>
              </DataGridTemplateColumn.CellTemplate>
            </DataGridTemplateColumn>
            <DataGridTextColumn Header="Port" Binding="{Binding Port}" Width="0.6*"/>
          </DataGrid.Columns>
        </DataGrid>
      </DockPanel>
    </GroupBox>

    <!-- Results + Log -->
    <GroupBox Grid.Row="2" Grid.Column="0" Header="Per-host Results" Margin="8,0,4,0">
      <DataGrid x:Name="gridResults" AutoGenerateColumns="False" CanUserAddRows="False" IsReadOnly="True" Margin="8">
        <DataGrid.Columns>
          <DataGridTextColumn Header="Host"   Binding="{Binding Host}"   Width="2*"/>
          <DataGridTextColumn Header="Check"  Binding="{Binding Check}"  Width="*"/>
          <DataGridTextColumn Header="Status" Binding="{Binding Status}" Width="*"/>
          <DataGridTextColumn Header="Detail" Binding="{Binding Detail}" Width="3*"/>
        </DataGrid.Columns>
      </DataGrid>
    </GroupBox>

    <GroupBox Grid.Row="2" Grid.Column="1" Header="Log" Margin="4,0,8,0">
      <DockPanel>
        <Button x:Name="btnOpenLog" Content="Open Log" DockPanel.Dock="Top" HorizontalAlignment="Right" Margin="8,6,8,0"/>
        <TextBox x:Name="txtLog" Margin="8" FontFamily="Consolas" FontSize="12" AcceptsReturn="True"
                 VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto"
                 IsReadOnly="True" Background="{StaticResource LogBg}" Foreground="#C9C9C9"/>
      </DockPanel>
    </GroupBox>

    <!-- Actions -->
    <GroupBox Grid.Row="3" Grid.ColumnSpan="2" Header="Actions" Margin="0,8,0,0">
      <DockPanel LastChildFill="False" Margin="0,8,0,0">
        <StackPanel Orientation="Horizontal" DockPanel.Dock="Left" Margin="6,0,6,0">
          <TextBox x:Name="txtReports" Width="420"/>
          <Button x:Name="btnBrowseReports" Content="Browse"/>
          <Button x:Name="btnOpenOut"      Content="Open Reports"/>
        </StackPanel>
        <StackPanel Orientation="Horizontal" DockPanel.Dock="Right" Margin="6,0,6,0">
          <Button x:Name="btnTest"       Content="Test Connection"/>
          <Button x:Name="btnRun"        Content="Run Readiness"/>
          <Button x:Name="btnCancel"     Content="Cancel" IsEnabled="False"/>
          <Button x:Name="btnOpenExcel"  Content="Open Last Excel"/>
          <Button x:Name="btnClose"      Content="Close"/>
        </StackPanel>
      </DockPanel>
    </GroupBox>

  </Grid>
</Window>
'@

$script:window = [Windows.Markup.XamlReader]::Parse($xaml)
$script:window.Title = 'Achieve One—Leadership to Adapt—Expertise to Achieve'

$names = 'lblPS','lblPCLI','lblExcel','lblOpenSSH','lblVsanJson',
         'chkUseBCG','chkUseVSANJson','chkVsanResidue',
         'btnInstallPCLI','btnInstallExcel','btnRecheck','btnGetVsanHcl',
         'grid','gridResults','btnAdd','btnRemove','btnLoad','btnSave',
         'cmbEsxiTarget','txtLog','btnOpenLog','btnOpenOut','btnBrowseReports',
         'txtReports','btnTest','btnRun','btnCancel','btnOpenExcel','btnClose'
foreach($n in $names){ Set-Variable -Name $n -Scope Script -Value ($script:window.FindName($n)) }

$script:txtReports.Text = $script:RunBase

# --- Data sources & binding ----------------------------------------------------
$script:Targets = New-Object System.Collections.ObjectModel.ObservableCollection[psobject]
$script:Rows    = New-Object System.Collections.ObjectModel.ObservableCollection[psobject]
$script:grid.ItemsSource        = $script:Targets
$script:gridResults.ItemsSource = $script:Rows

# Password binding
$handler = [System.Windows.RoutedEventHandler]{ param($sender,$e)
  try { $pwd=[System.Windows.Controls.PasswordBox]$e.OriginalSource; $row=$pwd.Tag; if ($row -and ($row.PSObject.Properties['Password'])) { $row.Password=$pwd.Password } } catch {}
}
$script:grid.AddHandler([System.Windows.Controls.PasswordBox]::PasswordChangedEvent, $handler)

# --- Helpers -------------------------------------------------------------------
Add-Type -AssemblyName System.Windows.Forms | Out-Null
function Do-Events { [System.Windows.Forms.Application]::DoEvents() | Out-Null }

function Has-Module([string]$Name) { !!(Get-Module -ListAvailable -Name $Name | Select-Object -First 1) }
function Try-Import([string]$Name) { try { Import-Module $Name -ErrorAction Stop | Out-Null; $true } catch { $false } }

function Set-StatusText([System.Windows.Controls.TextBlock]$Label,[string]$Text,[string]$State){
  $Label.Text = $Text
  switch($State){
    'OK'   { $Label.Foreground=[Windows.Media.Brushes]::LightGreen }
    'WARN' { $Label.Foreground=[Windows.Media.Brushes]::Gold }
    'FAIL' { $Label.Foreground=[Windows.Media.Brushes]::Tomato }
    default{ $Label.Foreground=[Windows.Media.Brushes]::White }
  }
}

function Normalize-Text([string]$s){
  if([string]::IsNullOrWhiteSpace($s)){ return $s }
  ($s -replace '\(R\)|\(TM\)','' -replace 'CPU','' -replace '@.*$','' -replace '\s+',' ').Trim()
}
function Compare-Version([string]$a,[string]$b){
  if([string]::IsNullOrWhiteSpace($a) -or [string]::IsNullOrWhiteSpace($b)){ return 0 }
  $pa=$a -split '[^0-9]+' | ?{$_}; $pb=$b -split '[^0-9]+' | ?{$_}
  $len=[Math]::Max($pa.Count,$pb.Count)
  for($i=0;$i -lt $len;$i++){
    $va= if($i -lt $pa.Count){ [int]$pa[$i] } else { 0 }
    $vb= if($i -lt $pb.Count){ [int]$pb[$i] } else { 0 }
    if($va -gt $vb){ return 1 } elseif($va -lt $vb){ return -1 }
  }
  0
}

# --- Prerequisites -------------------------------------------------------------
function Prereq-Check{
  $ok = $true

  # PS
  $isPS7 = $PSVersionTable.PSVersion.Major -ge 7
  Set-StatusText -Label $script:lblPS -Text ("PowerShell {0}" -f $PSVersionTable.PSVersion) -State ($isPS7 ? 'OK':'FAIL')
  $ok = $ok -and $isPS7

  # OpenSSH
  $sshOK   = (Get-Command ssh -EA SilentlyContinue) -and (Get-Command scp -EA SilentlyContinue)
  $sshText = $sshOK ? 'Found' : 'Not found'
  $sshState= $sshOK ? 'OK'    : 'WARN'
  Set-StatusText -Label $script:lblOpenSSH -Text $sshText -State $sshState

  # PowerCLI
  $hasPCLI = Has-Module 'VMware.VimAutomation.Core'
  if($hasPCLI){ Try-Import 'VMware.VimAutomation.Core' | Out-Null; Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false -EA SilentlyContinue | Out-Null }
  Set-StatusText -Label $script:lblPCLI -Text ($hasPCLI ? 'Found':'Not found') -State ($hasPCLI ? 'OK':'FAIL')
  $ok = $ok -and $hasPCLI

  # ImportExcel
  $hasExcel = Has-Module 'ImportExcel'
  if($hasExcel){ Try-Import 'ImportExcel' | Out-Null }
  Set-StatusText -Label $script:lblExcel -Text ($hasExcel ? 'Found':'Not found') -State ($hasExcel ? 'OK':'WARN')

  # vSAN HCL JSON
  $all1 = Join-Path $script:RunBase   'all.json'
  $all2 = Join-Path $script:ScriptBase 'all.json'
  $vsanFound = (Test-Path $all1) -or (Test-Path $all2)
  Set-StatusText -Label $script:lblVsanJson -Text ($vsanFound ? 'Found' : 'Not found (optional)') -State ($vsanFound ? 'OK':'WARN')

  if($script:btnRun){ $script:btnRun.IsEnabled=$ok }
  return $ok
}
$null = Prereq-Check

# --- Install buttons & utilities ----------------------------------------------
$script:btnInstallPCLI.Add_Click({
  try {
    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -EA SilentlyContinue | Out-Null
    Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -EA SilentlyContinue | Out-Null
    Install-Module VMware.PowerCLI -Scope CurrentUser -Force -AllowClobber -AcceptLicense -EA Stop
    Try-Import 'VMware.VimAutomation.Core' | Out-Null
    Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false -EA SilentlyContinue | Out-Null
    Write-Log "VMware.PowerCLI installed/updated."
  } catch { Write-Log ("PowerCLI install failed: {0}" -f $_.Exception.Message) 'ERROR' }
  Prereq-Check | Out-Null
})
$script:btnInstallExcel.Add_Click({
  try {
    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -EA SilentlyContinue | Out-Null
    Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -EA SilentlyContinue | Out-Null
    Install-Module ImportExcel -Scope CurrentUser -Force -EA Stop
    Try-Import 'ImportExcel' | Out-Null
    Write-Log "ImportExcel installed/updated."
  } catch { Write-Log ("ImportExcel install failed: {0}" -f $_.Exception.Message) 'ERROR' }
  Prereq-Check | Out-Null
})
$script:btnRecheck.Add_Click({ Prereq-Check | Out-Null })
$script:btnGetVsanHcl.Add_Click({ Start-Process "https://storage.googleapis.com/vsan-hcl-updates/all.json" })

# --- Targets: Add/Remove/Load/Save --------------------------------------------
$script:btnAdd.Add_Click({ $script:Targets.Add([pscustomobject]@{TargetHost='';Username='root';Password='';Port=443}) | Out-Null })
$script:btnRemove.Add_Click({ $sel=@($script:grid.SelectedItems); foreach($r in $sel){ [void]$script:Targets.Remove($r) } })
$script:btnLoad.Add_Click({
  try {
    $dlg=New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Filter="CSV files (*.csv)|*.csv|All files (*.*)|*.*"
    $dlg.Title="Select targets CSV (TargetHost,Username,[Password],[Port])"
    if($dlg.ShowDialog() -eq $true){
      $csv=Import-Csv -Path $dlg.FileName
      $script:Targets.Clear()
      foreach($row in $csv){
        $pwd  = if($row.PSObject.Properties['Password']){ $row.Password } else { '' }
        $port = if($row.PSObject.Properties['Port'])    { [int]$row.Port } else { 443 }
        $script:Targets.Add([pscustomobject]@{
          TargetHost = $row.TargetHost
          Username   = $row.Username
          Password   = $pwd
          Port       = $port
        }) | Out-Null
      }
      Write-Log ("Loaded {0} target(s)" -f $script:Targets.Count)
    }
  } catch { Write-Log ("Load targets failed: {0}" -f $_.Exception.Message) 'ERROR' }
})
$script:btnSave.Add_Click({
  try {
    $dlg=New-Object Microsoft.Win32.SaveFileDialog
    $dlg.Filter="CSV files (*.csv)|*.csv|All files (*.*)|*.*"
    $dlg.Title="Save targets CSV"
    $dlg.FileName="Targets.csv"
    if($dlg.ShowDialog() -eq $true){
      $script:Targets | Export-Csv -Path $dlg.FileName -NoTypeInformation -Encoding UTF8
      Write-Log ("Saved targets -> {0}" -f $dlg.FileName)
    }
  } catch { Write-Log ("Save targets failed: {0}" -f $_.Exception.Message) 'ERROR' }
})

# --- Actions: browse/open/log/excel/close -------------------------------------
$script:btnBrowseReports.Add_Click({
  try { $dlg=New-Object System.Windows.Forms.FolderBrowserDialog; $dlg.SelectedPath=$script:RunBase
    if($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){ $script:RunBase=$dlg.SelectedPath; $script:txtReports.Text=$script:RunBase } } catch {} })
$script:btnOpenOut.Add_Click({ try { if(Test-Path $script:RunDir){ Start-Process explorer.exe $script:RunDir } else { Start-Process explorer.exe $script:RunBase } } catch {} })
$script:btnOpenLog.Add_Click({ try { if(Test-Path $Global:LogFile){ Start-Process notepad.exe $Global:LogFile } } catch {} })
$script:btnOpenExcel.Add_Click({ try { $last=Get-ChildItem -Path $script:RunDir -Filter '*.xlsx' | Sort-Object LastWriteTime -Descending | Select-Object -First 1; if($last){ Start-Process $last.FullName } } catch {} })
$script:btnClose.Add_Click({ try { $script:window.Close() } catch {} })

# --- Jobs helper ---------------------------------------------------------------
try { Import-Module ThreadJob -ErrorAction SilentlyContinue | Out-Null } catch {}
function Enable-RunButtons($enable){ $script:btnRun.IsEnabled=$enable; $script:btnTest.IsEnabled=$enable; $script:btnCancel.IsEnabled = -not $enable }

# --- Test Connection -----------------------------------------------------------
$script:RunJobs = New-Object System.Collections.Generic.List[System.Management.Automation.Job]
$script:btnTest.Add_Click({
  try {
    if (-not (Has-Module 'VMware.VimAutomation.Core')) { [System.Windows.MessageBox]::Show("Install VMware.PowerCLI first.","Readiness") | Out-Null; return }
    Try-Import 'VMware.VimAutomation.Core' | Out-Null
    Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false -EA SilentlyContinue | Out-Null

    Enable-RunButtons $false
    Write-Log "Starting test(s)..."
    $script:Rows.Clear(); $script:gridResults.Items.Refresh()
    $script:RunJobs.Clear()

    $targets=@($script:Targets | ForEach-Object { $_ })
    foreach($t in $targets){
      if([string]::IsNullOrWhiteSpace($t.TargetHost) -or [string]::IsNullOrWhiteSpace($t.Username)){
        $script:Rows.Add([pscustomobject]@{Host=$t.TargetHost;Check='Input';Status='Info';Detail='Host & Username required'}) | Out-Null
        $script:gridResults.Items.Refresh(); continue
      }
      $TargetHost=$t.TargetHost; $User=$t.Username; $Pass=$t.Password
      $job = Start-ThreadJob -ArgumentList $TargetHost,$User,$Pass -ScriptBlock {
        param($TargetHost,$User,$Pass)
        try {
          Import-Module VMware.VimAutomation.Core -ErrorAction Stop | Out-Null
          Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false -EA SilentlyContinue | Out-Null
          $vi = Connect-VIServer -Server $TargetHost -User $User -Password $Pass -Force -WarningAction SilentlyContinue -ErrorAction Stop
          try {
            $ver = (Get-View ServiceInstance).Content.About.FullName
            [pscustomobject]@{Host=$TargetHost; Check='Connect'; Status='Pass'; Detail=$ver}
          } finally { if($vi){ Disconnect-VIServer -Server $vi -Force -Confirm:$false | Out-Null } }
        } catch {
          [pscustomobject]@{Host=$TargetHost; Check='Connect'; Status='Fail'; Detail=$_.Exception.Message}
        }
      }
      [void]$script:RunJobs.Add($job)
    }

    while($script:RunJobs.Where({ $_.State -in 'Running','NotStarted' }).Count){ Start-Sleep -Milliseconds 150; Do-Events }
    foreach($j in @($script:RunJobs)){
      try { $res=Receive-Job -Job $j -ErrorAction SilentlyContinue; if($res){ $script:Rows.Add($res) | Out-Null; $script:gridResults.Items.Refresh(); Write-Log ("[{0}] Test: {1} — {2}" -f $res.Host,$res.Status,$res.Detail) } }
      catch { Write-Log ("Test job error: {0}" -f $_.Exception.Message) 'ERROR' }
      finally { try{ Remove-Job -Job $j -Force -EA SilentlyContinue }catch{}; [void]$script:RunJobs.Remove($j) }
    }
  } catch {
    Write-Log ("Test error: {0}" -f $_.Exception.Message) 'ERROR'
    [System.Windows.MessageBox]::Show("Test error:`n"+$_.Exception.Message) | Out-Null
  } finally { Enable-RunButtons $true }
})

# --- Run Readiness (CPU normalize + IO/SSD + Neighbors) ------------------------
$script:btnRun.Add_Click({
  try {
    if (-not (Has-Module 'VMware.VimAutomation.Core')) { [System.Windows.MessageBox]::Show("Install VMware.PowerCLI first.","Readiness") | Out-Null; return }
    Try-Import 'VMware.VimAutomation.Core' | Out-Null
    Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false -EA SilentlyContinue | Out-Null

    Enable-RunButtons $false
    Write-Log "==== Starting readiness ===="

    $EsxTarget     = $script:cmbEsxiTarget.Text
    $UseBCG        = [bool]$script:chkUseBCG.IsChecked
    $CheckResidue  = [bool]$script:chkVsanResidue.IsChecked

    # Load BCG JSONs
    $BcgCpuRaw = $null; $BcgIoRaw = $null; $BcgSsdRaw=$null
    if($UseBCG){
      foreach($fn in 'bcg_cpu.json','bcg_io.json','bcg_ssd.json'){
        $p1=Join-Path $script:RunBase   $fn
        $p2=Join-Path $script:ScriptBase $fn
        switch($fn){
          'bcg_cpu.json' { if(Test-Path $p1){$BcgCpuRaw=Get-Content $p1 -Raw} elseif(Test-Path $p2){$BcgCpuRaw=Get-Content $p2 -Raw} }
          'bcg_io.json'  { if(Test-Path $p1){$BcgIoRaw =Get-Content $p1 -Raw} elseif(Test-Path $p2){$BcgIoRaw =Get-Content $p2 -Raw} }
          'bcg_ssd.json' { if(Test-Path $p1){$BcgSsdRaw=Get-Content $p1 -Raw} elseif(Test-Path $p2){$BcgSsdRaw=Get-Content $p2 -Raw} }
        }
      }
    }

    $script:Rows.Clear(); $script:gridResults.Items.Refresh()
    $script:RunJobs.Clear()

    $targets=@($script:Targets | ForEach-Object { $_ })
    foreach($t in $targets){
      if([string]::IsNullOrWhiteSpace($t.TargetHost) -or [string]::IsNullOrWhiteSpace($t.Username)){
        $script:Rows.Add([pscustomobject]@{Host=$t.TargetHost;Check='Run';Status='Fail';Detail='Missing Host/Username'}) | Out-Null
        $script:gridResults.Items.Refresh(); continue
      }
      Write-Log ("Queueing checks on {0}" -f $t.TargetHost)
      $TargetHost=$t.TargetHost; $User=$t.Username; $Pass=$t.Password; $Port= if($t.Port){[int]$t.Port}else{443}

      $job = Start-ThreadJob -ArgumentList $TargetHost,$User,$Pass,$EsxTarget,$UseBCG,$CheckResidue,$BcgCpuRaw,$BcgIoRaw,$BcgSsdRaw -ScriptBlock {
        param($TargetHost,$User,$Pass,$EsxTarget,$UseBCG,$CheckResidue,$BcgCpuRaw,$BcgIoRaw,$BcgSsdRaw)

        function _importPcli { try { Import-Module VMware.VimAutomation.Core -ErrorAction Stop | Out-Null; Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false -EA SilentlyContinue | Out-Null; $true } catch { $false } }
        function Normalize-Text([string]$s){ if(-not $s){ return $s } ($s -replace '\(R\)|\(TM\)','' -replace 'CPU','' -replace '@.*$','' -replace '\s+',' ').Trim() }
        function Compare-Version([string]$a,[string]$b){ if(-not $a -or -not $b){return 0}; $pa=$a -split '[^0-9]+' | ?{$_}; $pb=$b -split '[^0-9]+' | ?{$_}; $len=[Math]::Max($pa.Count,$pb.Count); for($i=0;$i -lt $len;$i++){ $va=if($i -lt $pa.Count){[int]$pa[$i]}else{0}; $vb=if($i -lt $pb.Count){[int]$pb[$i]}else{0}; if($va -gt $vb){return 1}elseif($va -lt $vb){return -1} }; 0 }

        $rows = New-Object System.Collections.Generic.List[psobject]
        try {
          if (-not (_importPcli)) { throw "PowerCLI not available in job." }
          $vi = Connect-VIServer -Server $TargetHost -User $User -Password $Pass -Force -WarningAction SilentlyContinue -ErrorAction Stop
          try {
            $vmh  = Get-VMHost -Server $vi

            # NTP
            try { $ntps = $vmh | Get-VMHostNtpServer -EA SilentlyContinue; $svc  = $vmh | Get-VMHostService | Where-Object { $_.Key -eq 'ntpd' }; $rows.Add([pscustomobject]@{Host=$TargetHost;Check='NTP Servers';       Status=$(if($ntps){'Pass'}else{'Fail'}); Detail=($ntps -join ',')}) | Out-Null; $rows.Add([pscustomobject]@{Host=$TargetHost;Check='NTP Startup Policy'; Status=$(if($svc -and $svc.Policy -match 'on\s*automatic'){'Pass'}else{'Fail'}); Detail=$svc.Policy}) | Out-Null } catch {}

            # Certificate
            try {
              $tcp = New-Object System.Net.Sockets.TcpClient; $tcp.Connect($TargetHost,443)
              $ssl = New-Object System.Net.Security.SslStream($tcp.GetStream(),$false,({$true}))
              $ssl.AuthenticateAsClient($TargetHost)
              $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($ssl.RemoteCertificate)
              $dns=@(); foreach($ext in $cert.Extensions){ if($ext.Oid.FriendlyName -eq 'Subject Alternative Name'){ $san=$ext.Format($true); $dns += ($san -split '[\r\n]' | Where-Object { $_ -match 'DNS Name=(.+)$' } | ForEach-Object { ($Matches[1]).Trim() }) } }
              $cn = if($cert.Subject -match 'CN\s*=\s*([^,]+)'){ $Matches[1] } else { '' }
              $dom = ( ($TargetHost -split '\.',2) | Select-Object -Skip 1 )
              $wild = ($dom) -and ($dns -contains ("*."+ $dom))
              $ok = ($TargetHost -ieq $cn) -or ($dns -contains $TargetHost) -or $wild
              $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Server Certificate';Status=$(if($ok){'Pass'}else{'Fail'});Detail=("CN={0}; SAN={1}" -f $cn,($dns -join ','))}) | Out-Null
            } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Server Certificate';Status='Fail';Detail=$_.Exception.Message}) | Out-Null }
            finally { try{$ssl.Dispose()}catch{}; try{$tcp.Dispose()}catch{} }

            # vSAN residue
            if ($CheckResidue) {
              try { $cli = Get-EsxCli -VMHost $vmh -V2; $text=''; try{ $list=$cli.vsan.storage.list.Invoke(); $text=($list|Out-String) }catch{}; $hit=$false; if($text){ if($text -match '(?i)\bvsan\b' -and ($text -match '(?i)inuse|claimed|disk\s*group|uuid')){ $hit=$true } }; $rows.Add([pscustomobject]@{Host=$TargetHost;Check='vSAN Residue';Status=$(if($hit){'Fail'}else{'Pass'});Detail=$(if($hit){'Leftover vSAN claim/partitions detected'}else{'No residue detected'})}) | Out-Null } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='vSAN Residue';Status='Unknown';Detail=$_.Exception.Message}) | Out-Null }
            }

            # CPU BCG (normalized + regex)
            if ($UseBCG -and $BcgCpuRaw) {
              try {
                $bcg = $BcgCpuRaw | ConvertFrom-Json -EA Stop
                $view = $vmh | Get-View -Property Name,Hardware
                $cpuRaw  = ($view.Hardware.CpuPkg | Select-Object -First 1).Description
                $cpu     = Normalize-Text $cpuRaw
                $match   = $null
                foreach($e in $bcg){
                  $m = Normalize-Text $e.match
                  if ($m -and ($cpu -like ("*"+$m+"*"))) { $match=$e; break }
                  elseif ($e.PSObject.Properties['regex']) { try{ if($cpuRaw -match $e.regex){ $match=$e; break } }catch{} }
                }
                if ($match -and $match.esxi) {
                  $supported = ($match.esxi -contains $EsxTarget)
                  $rows.Add([pscustomobject]@{Host=$TargetHost;Check='CPU BCG';Status=$(if($supported){'Pass'}else{'Fail'});Detail=("CPU={0}; Match={1}; Supports=[{2}]" -f $cpuRaw,$match.match,($match.esxi -join ','))}) | Out-Null
                } else {
                  $rows.Add([pscustomobject]@{Host=$TargetHost;Check='CPU BCG';Status='Unknown';Detail=("CPU={0}; No match in bcg_cpu.json" -f $cpuRaw)}) | Out-Null
                }
              } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='CPU BCG';Status='Unknown';Detail=$_.Exception.Message}) | Out-Null }
            }

            # IO BCG (NIC/HBA)
            if ($UseBCG -and $BcgIoRaw) {
              try {
                $io = $BcgIoRaw | ConvertFrom-Json -EA Stop
                $cli = Get-EsxCli -VMHost $vmh -V2
                $vibs=@(); try { $vibs = $cli.software.vib.list.Invoke() } catch {}
                $pnics=@(); try { $pnics= Get-VMHostPnic -VMHost $vmh -EA SilentlyContinue } catch {}
                $hbas =@(); try { $hbas = Get-VMHostHba  -VMHost $vmh -EA SilentlyContinue } catch {}
                $pci  =@(); try { $pci  = $cli.hardware.pci.list.Invoke() } catch {}
                $drvVer=@{}; foreach($v in $vibs){ if($v -and $v.Name){ $drvVer[$v.Name.ToLower()] = $v.Version } }

                foreach($n in $pnics){
                  $drv=$n.Driver
                  $ver= if($drv -and $drvVer.ContainsKey($drv.ToLower())){ $drvVer[$drv.ToLower()] } else { '' }
                  $detail = "NIC {0} {1} Driver={2} {3}" -f $n.Name,$n.Model,$drv,$ver
                  $class='NIC'; $status='Unknown'; $note='no rule'
                  foreach($rule in $io){
                    $hit=$false
                    if($rule.class -and $rule.class -ne $class){ continue }
                    if($rule.match -and ($n.Model -like ("*"+$rule.match+"*"))){ $hit=$true }
                    if(-not $hit -and $rule.vid -and $rule.did){
                      $pciEnt = $null; try { $pciEnt = $pci | Where-Object { $_.DeviceAddress -eq $n.Pci } | Select-Object -First 1 } catch {}
                      if($pciEnt){
                        $v = ($pciEnt.VendorID -replace '^0x','').ToLower()
                        $d = ($pciEnt.DeviceID -replace '^0x','').ToLower()
                        if($v -eq $rule.vid.ToLower() -and $d -eq $rule.did.ToLower()){ $hit=$true }
                      }
                    }
                    if($hit){
                      $supported = ($rule.esxi -contains $EsxTarget)
                      $status=$(if($supported){'Pass'}else{'Fail'})
                      if($rule.driver -and $rule.driver.name){
                        if($drv -and ($drv.ToLower() -eq $rule.driver.name.ToLower())){
                          if($rule.driver.min){
                            if((Compare-Version $ver $rule.driver.min) -lt 0){ $status='Fail'; $note='driver<min' }
                          }
                        } else { $status='Fail'; $note='driver!=rule' }
                      }
                      break
                    }
                  }
                  $rows.Add([pscustomobject]@{Host=$TargetHost;Check='IO BCG';Status=$status;Detail=($detail + $(if($note -and $note -ne 'no rule'){ "; Note="+$note } else { '' }))}) | Out-Null
                }

                foreach($h in $hbas){
                  $drv=$h.Driver
                  $ver= if($drv -and $drvVer.ContainsKey($drv.ToLower())){ $drvVer[$drv.ToLower()] } else { '' }
                  $detail = "HBA {0} {1} Driver={2} {3}" -f $h.Name,$h.Model,$drv,$ver
                  $class='HBA'; $status='Unknown'; $note='no rule'
                  foreach($rule in $io){
                    if($rule.class -and $rule.class -ne $class){ continue }
                    $hit=$false
                    if($rule.match -and ($h.Model -like ("*"+$rule.match+"*"))){ $hit=$true }
                    if(-not $hit -and $rule.vid -and $rule.did){
                      $pciEnt = $null; try { $pciEnt = $pci | Where-Object { $_.DeviceAddress -eq $h.Pci } | Select-Object -First 1 } catch {}
                      if($pciEnt){
                        $v = ($pciEnt.VendorID -replace '^0x','').ToLower()
                        $d = ($pciEnt.DeviceID -replace '^0x','').ToLower()
                        if($v -eq $rule.vid.ToLower() -and $d -eq $rule.did.ToLower()){ $hit=$true }
                      }
                    }
                    if($hit){
                      $supported=($rule.esxi -contains $EsxTarget)
                      $status=$(if($supported){'Pass'}else{'Fail'})
                      if($rule.driver -and $rule.driver.name){
                        if($drv -and ($drv.ToLower() -eq $rule.driver.name.ToLower())){
                          if($rule.driver.min){
                            if((Compare-Version $ver $rule.driver.min) -lt 0){ $status='Fail'; $note='driver<min' }
                          }
                        } else { $status='Fail'; $note='driver!=rule' }
                      }
                      break
                    }
                  }
                  $rows.Add([pscustomobject]@{Host=$TargetHost;Check='IO BCG';Status=$status;Detail=($detail + $(if($note -and $note -ne 'no rule'){ "; Note="+$note } else { '' }))}) | Out-Null
                }
              } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='IO BCG';Status='Unknown';Detail=$_.Exception.Message}) | Out-Null }
            }

            # SSD BCG
            if ($UseBCG -and $BcgSsdRaw) {
              try {
                $ssdMap = $BcgSsdRaw | ConvertFrom-Json -EA Stop
                $cli2 = Get-EsxCli -VMHost $vmh -V2
                $devs=$null; try { $devs = $cli2.storage.core.device.list.Invoke() } catch {}
                foreach($d in ($devs | Where-Object { $_ -and $_.IsSsd -eq $true })){
                  $model = if($d.Model){ $d.Model } elseif($d.DisplayName){ $d.DisplayName } else { $null }
                  if(-not $model){ continue }
                  $m=$null; foreach($e in $ssdMap){ if($e.match -and ($model -like ("*"+$e.match+"*"))){ $m=$e; break } }
                  if($m){
                    $ok = ($m.esxi -contains $EsxTarget)
                    $rows.Add([pscustomobject]@{Host=$TargetHost;Check='SSD BCG';Status=$(if($ok){'Pass'}else{'Fail'});Detail=("Model={0}; Match={1}; Supports=[{2}]" -f $model,$m.match,($m.esxi -join ','))}) | Out-Null
                  }
                }
              } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='SSD BCG';Status='Unknown';Detail=$_.Exception.Message}) | Out-Null }
            }

            # Neighbors (CDP/LLDP)
            try {
              $net = Get-View $vmh.ExtensionData.ConfigManager.NetworkSystem
              $pn  = $net.NetworkInfo.Pnic
              $vss = Get-VirtualSwitch -VMHost $vmh -Standard -EA SilentlyContinue
              $vds = Get-VDSwitch -VMHost $vmh -EA SilentlyContinue
              $dvMap = @{}
              foreach($d in $vds){ try { $upl = Get-VMHostNetworkAdapter -VMHost $vmh -Physical -DistributedSwitch $d -EA SilentlyContinue; foreach($u in $upl){ $dvMap[$u.DeviceName] = $d.Name } } catch {} }
              foreach($p in $pn){
                $hint = $net.QueryNetworkHint($p.Device)
                $vs = ($vss | Where-Object { $_.Nic -contains $p.Device } | Select-Object -ExpandProperty Name -First 1)
                if(-not $vs -and $dvMap.ContainsKey($p.Device)){ $vs = $dvMap[$p.Device] }
                if($hint -and $hint.ConnectedSwitchPort){
                  $c=$hint.ConnectedSwitchPort
                  $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Neighbor';Status='CDP';Detail=("vmnic={0}; vSwitch={1}; Switch={2}; PortId={3}; MgmtAddr={4}; Platform={5}" -f $p.Device,$vs,$c.DevId,$c.PortId,$c.MgmtAddr,$c.HardwarePlatform)}) | Out-Null
                } elseif($hint -and $hint.LLDPInfo){
                  $sys  = ($hint.LLDPInfo.Parameter | Where-Object {$_.Key -eq 'System Name'} | Select-Object -ExpandProperty Value -First 1)
                  $port = ($hint.LLDPInfo.Parameter | Where-Object {$_.Key -in 'Port Description','Port ID'} | Select-Object -ExpandProperty Value -First 1)
                  $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Neighbor';Status='LLDP';Detail=("vmnic={0}; vSwitch={1}; Switch={2}; Port={3}" -f $p.Device,$vs,$sys,$port)}) | Out-Null
                } else {
                  $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Neighbor';Status='None';Detail=("vmnic={0}; vSwitch={1}; No discovery data" -f $p.Device,$vs)}) | Out-Null
                }
              }
            } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Neighbor';Status='Unknown';Detail=$_.Exception.Message}) | Out-Null }

          } finally { if($vi){ Disconnect-VIServer -Server $vi -Force -Confirm:$false | Out-Null } }
        } catch { $rows.Add([pscustomobject]@{Host=$TargetHost;Check='Error';Status='Fail';Detail=$_.Exception.Message}) | Out-Null }
        $rows
      }
      [void]$script:RunJobs.Add($job)
    }

    while($script:RunJobs.Where({ $_.State -in 'Running','NotStarted' }).Count){ Start-Sleep -Milliseconds 150; Do-Events }
    foreach($j in @($script:RunJobs)){
      try { $res = Receive-Job -Job $j -ErrorAction SilentlyContinue; if($res){ foreach($r in $res){ $script:Rows.Add($r) | Out-Null }; $script:gridResults.Items.Refresh() } }
      catch { Write-Log ("Run job error: {0}" -f $_.Exception.Message) 'ERROR' }
      finally { try{ Remove-Job -Job $j -Force -EA SilentlyContinue }catch{}; [void]$script:RunJobs.Remove($j) }
    }

    # Outputs
    $csv=Join-Path $script:RunDir 'PerHostRows.csv'
    $script:Rows | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
    Write-Log ("CSV saved: {0}" -f $csv)

    if (Has-Module 'ImportExcel') {
      try {
        Try-Import 'ImportExcel' | Out-Null
        $xlsx=Join-Path $script:RunDir ("VCF9-ESXi-Readiness-" + (Get-Date -Format 'yyyyMMdd-HHmmss') + ".xlsx")
        $script:Rows | Export-Excel -Path $xlsx -WorksheetName 'HostRows' -TableName 'HostRows' -AutoSize -FreezeTopRow
        $neighbors = $script:Rows | Where-Object { $_.Check -eq 'Neighbor' }
        if($neighbors){ $neighbors | Export-Excel -Path $xlsx -WorksheetName 'Neighbors' -AutoSize -FreezeTopRow -Append }
        Write-Log ("Excel saved: {0}" -f $xlsx)
      } catch { Write-Log ("Excel export failed: {0}" -f $_.Exception.Message) 'WARN' }
    } else { Write-Log "ImportExcel not installed — skipping Excel output." 'WARN' }

  } catch {
    Write-Log ("Run error: {0}" -f $_.Exception.Message) 'ERROR'
    [System.Windows.MessageBox]::Show("Run error:`n"+$_.Exception.Message) | Out-Null
  } finally { Enable-RunButtons $true }
})

# --- Cancel --------------------------------------------------------------------
$script:btnCancel.Add_Click({
  try {
    if ($script:RunJobs.Count -gt 0) {
      Write-Log ("Cancel requested. Stopping {0} job(s)..." -f $script:RunJobs.Count) 'WARN'
      foreach($j in @($script:RunJobs)){ try{ if ($j.State -in 'Running','NotStarted'){ Stop-Job -Job $j -Force -EA SilentlyContinue } } catch{} }
      Start-Sleep -Milliseconds 250
      foreach($j in @($script:RunJobs)){ try{ Remove-Job -Job $j -Force -EA SilentlyContinue }catch{}; [void]$script:RunJobs.Remove($j) }
      Write-Log "All running jobs stopped." 'WARN'
    }
  } finally { Enable-RunButtons $true }
})

# Seed a row for convenience
$script:Targets.Add([pscustomobject]@{TargetHost='10.10.10.10';Username='root';Password='';Port=443}) | Out-Null

# === FORCE UI SHOW (uses existing window; triggers prereq if available) ===
try {
    Write-Host ('[DBG ] Final STA={0}' -f [Threading.Thread]::CurrentThread.ApartmentState)
    # Ensure WPF assemblies (should already be loaded earlier)
    try { Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase -ErrorAction SilentlyContinue } catch {}

    if (-not $script:window) {
        Write-Host '[DBG ] $script:window was null at end — reparsing XAML once'
        $script:window = [Windows.Markup.XamlReader]::Parse($xaml)
    }

    # If a Prereq-Check function exists, call it once after content is rendered
    try {
        if (Get-Command Prereq-Check -ErrorAction SilentlyContinue) {
            $null = $script:window.Add_ContentRendered({ try { Prereq-Check | Out-Null } catch {} })
        }
    } catch {}

    # Show the already wired window
    Write-Host '[DBG ] Showing window (ShowDialog)'
    $null = $script:window.ShowDialog()
    Write-Host '[DBG ] Window closed'
} catch {
    Write-Host ("[ERR ] Final ShowDialog failed: {0}" -f $_.Exception.Message)
    throw
}

# SIG # Begin signature block
# MIId3wYJKoZIhvcNAQcCoIId0DCCHcwCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDmZeSUp/P29yCM
# pzWE0dnsVrYIEl8ju5aHws6mlu/nSKCCF4gwggRKMIICsqADAgECAhBUZ6AKJOtZ
# hET4y/4hrL7fMA0GCSqGSIb3DQEBCwUAMD0xOzA5BgNVBAMMMlZDRjkgUmVhZGlu
# ZXNzIExvY2FsIENvZGUgU2lnbmluZyAoeGFkbWluQEhPTUVMQUIpMB4XDTI1MTEw
# NjIyMDkzM1oXDTMwMTEwNjIyMTkzMlowPTE7MDkGA1UEAwwyVkNGOSBSZWFkaW5l
# c3MgTG9jYWwgQ29kZSBTaWduaW5nICh4YWRtaW5ASE9NRUxBQikwggGiMA0GCSqG
# SIb3DQEBAQUAA4IBjwAwggGKAoIBgQDhmO0QQGKZslnwXHD1xafSAUErzW8Cf4PP
# 33DPNw5+ftKCHD3FLbQdnKiW+Vs5g20zPVfeVsp0Yw7ixteW/jB7F+wSfWJuvAUU
# UxRa6uyGTf2lAaPuW7wRNjjAswMhRHh58xmDTelSBqoHzLDKqPeEkbuBdMfyWsrk
# 2bTLBQvU9PDXpkMoD4qP0g2YOfACTRAtGbojtNWFXdRqs8h5ICjfqQrBdWbU+EJJ
# i3ITSRrtXYTB+rWZaX4IFurMhazkF6LZ9iynz9hT3I0qEJnX/f2zkayz7rX9TfNQ
# WrlBjh0mLur4UmhMeDBmKnLAO3B5RuUvBjpagnXUEYUtyE7hrjRyC2+rijzNkWkk
# jm2cVmIijYxxLBdn7V83TYlhaxmUzXloKKmLLf6hYSenuWp05/1nwT1S+2dZGqzV
# LopqHMTSPpbA0VNbuAzvS3Ymb7TTZ9J73ErBXXe/BmuuM5VVEV/LinDCWbRR18wx
# f6lOzCllIJmB/rg48kMI5AZ6RovejvkCAwEAAaNGMEQwDgYDVR0PAQH/BAQDAgeA
# MBMGA1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSNZ1dKfBFqRk0PdDcYpwc5
# AOzJrTANBgkqhkiG9w0BAQsFAAOCAYEA2L7g7iSpo0tjuGb7MmAw0JRHT49cpIbC
# 5i+DHjaI0VvCq9X8EuwOYufsILETLzv12aSUpyJVzZqhg71gXaUb2tzc1EKSS41f
# 0zNpsud1nt+mMdyLUQvwdUIebSgSQdoMSxENBs6UlePLoR/HlL6jSDmjeHK/NJDW
# xbRi2CPybCwJ/i56lyuoPwEWG7wKDBpTPtQ+8wzgZGjPe0bjGthd/qrauvLPq0cI
# Q7FD4tI9eNFeFS8KOb/g7a2XJwLn1w/ed9HgJf8XDecSlUmzToOgIH4WvkeajUsn
# nrdouEAfP44uUmxLuOHuqWU1krkZWBFscN5d1JOaPmhv/2q3/HtnGxMDI7Nwvj2q
# 74PlsTxb/iiOuiv2VIFefiMWrQ5eLbpqrCqBaBQSJ83laLEVdxH7qexWd7P1y4iW
# 2DLG58A4GXfCipDtU0ZI+o83p4im2yEHUl43o4wsHDo7iRYzicAeE19B+Bo2RYgL
# r3GM7bGRmf1Zs5V5iCoVNJFAq8JqCOzkMIIFjTCCBHWgAwIBAgIQDpsYjvnQLefv
# 21DiCEAYWjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQD
# ExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAxMDAwMDAwWhcN
# MzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQg
# SW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2Vy
# dCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aaza57G4QNxDAf
# 8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllVcq9ok3DCsrp1
# mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT+CFhmzTrBcZe
# 7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd463JT17lNecx
# y9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+EJFwq1WCQTLX
# 2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92kJ7yhTzm1EVgX
# 9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5jrubU75KSOp49
# 3ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7f/LVjHAsQWCq
# sWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJUKSWJbOUOUlFH
# dL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+whX8QgUWtvsauG
# i0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQABo4IBOjCCATYw
# DwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5nP+e6mK4cD08w
# HwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0PAQH/BAQDAgGG
# MHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDwwOqA4oDaGNGh0
# dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5j
# cmwwEQYDVR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IBAQBwoL9DXFXn
# OF+go3QbPbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229GhT0E0p6Ly23
# OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FDRJtDIeuWcqFI
# tJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVGamlUsLihVo7s
# pNU96LHc/RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCwrFigDkBjxZgi
# wbJZ9VVrzyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvRXKwYw02fc7cB
# qZ9Xql4o4rmUMIIGtDCCBJygAwIBAgIQDcesVwX/IZkuQEMiDDpJhjANBgkqhkiG
# 9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkw
# FwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVz
# dGVkIFJvb3QgRzQwHhcNMjUwNTA3MDAwMDAwWhcNMzgwMTE0MjM1OTU5WjBpMQsw
# CQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERp
# Z2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hBMjU2IDIw
# MjUgQ0ExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAtHgx0wqYQXK+
# PEbAHKx126NGaHS0URedTa2NDZS1mZaDLFTtQ2oRjzUXMmxCqvkbsDpz4aH+qbxe
# Lho8I6jY3xL1IusLopuW2qftJYJaDNs1+JH7Z+QdSKWM06qchUP+AbdJgMQB3h2D
# Z0Mal5kYp77jYMVQXSZH++0trj6Ao+xh/AS7sQRuQL37QXbDhAktVJMQbzIBHYJB
# YgzWIjk8eDrYhXDEpKk7RdoX0M980EpLtlrNyHw0Xm+nt5pnYJU3Gmq6bNMI1I7G
# b5IBZK4ivbVCiZv7PNBYqHEpNVWC2ZQ8BbfnFRQVESYOszFI2Wv82wnJRfN20VRS
# 3hpLgIR4hjzL0hpoYGk81coWJ+KdPvMvaB0WkE/2qHxJ0ucS638ZxqU14lDnki7C
# coKCz6eum5A19WZQHkqUJfdkDjHkccpL6uoG8pbF0LJAQQZxst7VvwDDjAmSFTUm
# s+wV/FbWBqi7fTJnjq3hj0XbQcd8hjj/q8d6ylgxCZSKi17yVp2NL+cnT6Toy+rN
# +nM8M7LnLqCrO2JP3oW//1sfuZDKiDEb1AQ8es9Xr/u6bDTnYCTKIsDq1BtmXUqE
# G1NqzJKS4kOmxkYp2WyODi7vQTCBZtVFJfVZ3j7OgWmnhFr4yUozZtqgPrHRVHhG
# NKlYzyjlroPxul+bgIspzOwbtmsgY1MCAwEAAaOCAV0wggFZMBIGA1UdEwEB/wQI
# MAYBAf8CAQAwHQYDVR0OBBYEFO9vU0rp5AZ8esrikFb2L9RJ7MtOMB8GA1UdIwQY
# MBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUE
# DDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGGGGh0dHA6
# Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2NhY2VydHMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYDVR0fBDww
# OjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3Rl
# ZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMA0G
# CSqGSIb3DQEBCwUAA4ICAQAXzvsWgBz+Bz0RdnEwvb4LyLU0pn/N0IfFiBowf0/D
# m1wGc/Do7oVMY2mhXZXjDNJQa8j00DNqhCT3t+s8G0iP5kvN2n7Jd2E4/iEIUBO4
# 1P5F448rSYJ59Ib61eoalhnd6ywFLerycvZTAz40y8S4F3/a+Z1jEMK/DMm/axFS
# goR8n6c3nuZB9BfBwAQYK9FHaoq2e26MHvVY9gCDA/JYsq7pGdogP8HRtrYfctSL
# ANEBfHU16r3J05qX3kId+ZOczgj5kjatVB+NdADVZKON/gnZruMvNYY2o1f4MXRJ
# DMdTSlOLh0HCn2cQLwQCqjFbqrXuvTPSegOOzr4EWj7PtspIHBldNE2K9i697cva
# iIo2p61Ed2p8xMJb82Yosn0z4y25xUbI7GIN/TpVfHIqQ6Ku/qjTY6hc3hsXMrS+
# U0yy+GWqAXam4ToWd2UQ1KYT70kZjE4YtL8Pbzg0c1ugMZyZZd/BdHLiRu7hAWE6
# bTEm4XYRkA6Tl4KSFLFk43esaUeqGkH/wyW4N7OigizwJWeukcyIPbAvjSabnf7+
# Pu0VrFgoiovRDiyx3zEdmcif/sYQsfch28bZeUz2rtY/9TCA6TD8dC3JE3rYkrhL
# ULy7Dc90G6e8BlqmyIjlgp2+VqsS9/wQD7yFylIz0scmbKvFoW2jNrbM1pD2T7m3
# XDCCBu0wggTVoAMCAQICEAqA7xhLjfEFgtHEdqeVdGgwDQYJKoZIhvcNAQELBQAw
# aTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEwPwYDVQQD
# EzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVTdGFtcGluZyBSU0E0MDk2IFNIQTI1
# NiAyMDI1IENBMTAeFw0yNTA2MDQwMDAwMDBaFw0zNjA5MDMyMzU5NTlaMGMxCzAJ
# BgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGln
# aUNlcnQgU0hBMjU2IFJTQTQwOTYgVGltZXN0YW1wIFJlc3BvbmRlciAyMDI1IDEw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDQRqwtEsae0OquYFazK1e6
# b1H/hnAKAd/KN8wZQjBjMqiZ3xTWcfsLwOvRxUwXcGx8AUjni6bz52fGTfr6PHRN
# v6T7zsf1Y/E3IU8kgNkeECqVQ+3bzWYesFtkepErvUSbf+EIYLkrLKd6qJnuzK8V
# cn0DvbDMemQFoxQ2Dsw4vEjoT1FpS54dNApZfKY61HAldytxNM89PZXUP/5wWWUR
# K+IfxiOg8W9lKMqzdIo7VA1R0V3Zp3DjjANwqAf4lEkTlCDQ0/fKJLKLkzGBTpx6
# EYevvOi7XOc4zyh1uSqgr6UnbksIcFJqLbkIXIPbcNmA98Oskkkrvt6lPAw/p4oD
# SRZreiwB7x9ykrjS6GS3NR39iTTFS+ENTqW8m6THuOmHHjQNC3zbJ6nJ6SXiLSvw
# 4Smz8U07hqF+8CTXaETkVWz0dVVZw7knh1WZXOLHgDvundrAtuvz0D3T+dYaNcwa
# fsVCGZKUhQPL1naFKBy1p6llN3QgshRta6Eq4B40h5avMcpi54wm0i2ePZD5pPIs
# soszQyF4//3DoK2O65Uck5Wggn8O2klETsJ7u8xEehGifgJYi+6I03UuT1j7Fnrq
# VrOzaQoVJOeeStPeldYRNMmSF3voIgMFtNGh86w3ISHNm0IaadCKCkUe2LnwJKa8
# TIlwCUNVwppwn4D3/Pt5pwIDAQABo4IBlTCCAZEwDAYDVR0TAQH/BAIwADAdBgNV
# HQ4EFgQU5Dv88jHt/f3X85FxYxlQQ89hjOgwHwYDVR0jBBgwFoAU729TSunkBnx6
# yuKQVvYv1Ensy04wDgYDVR0PAQH/BAQDAgeAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMIGVBggrBgEFBQcBAQSBiDCBhTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3Au
# ZGlnaWNlcnQuY29tMF0GCCsGAQUFBzAChlFodHRwOi8vY2FjZXJ0cy5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRUcnVzdGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hBMjU2
# MjAyNUNBMS5jcnQwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDovL2NybDMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0VGltZVN0YW1waW5nUlNBNDA5NlNIQTI1
# NjIwMjVDQTEuY3JsMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATAN
# BgkqhkiG9w0BAQsFAAOCAgEAZSqt8RwnBLmuYEHs0QhEnmNAciH45PYiT9s1i6UK
# tW+FERp8FgXRGQ/YAavXzWjZhY+hIfP2JkQ38U+wtJPBVBajYfrbIYG+Dui4I4PC
# vHpQuPqFgqp1PzC/ZRX4pvP/ciZmUnthfAEP1HShTrY+2DE5qjzvZs7JIIgt0GCF
# D9ktx0LxxtRQ7vllKluHWiKk6FxRPyUPxAAYH2Vy1lNM4kzekd8oEARzFAWgeW3a
# z2xejEWLNN4eKGxDJ8WDl/FQUSntbjZ80FU3i54tpx5F/0Kr15zW/mJAxZMVBrTE
# 2oi0fcI8VMbtoRAmaaslNXdCG1+lqvP4FbrQ6IwSBXkZagHLhFU9HCrG/syTRLLh
# Aezu/3Lr00GrJzPQFnCEH1Y58678IgmfORBPC1JKkYaEt2OdDh4GmO0/5cHelAK2
# /gTlQJINqDr6JfwyYHXSd+V08X1JUPvB4ILfJdmL+66Gp3CSBXG6IwXMZUXBhtCy
# Iaehr0XkBoDIGMUG1dUtwq1qmcwbdUfcSYCn+OwncVUXf53VJUNOaMWMts0VlRYx
# e5nK+At+DI96HAlXHAL5SlfYxJ7La54i71McVWRP66bW+yERNpbJCjyCYG2j+bdp
# xo/1Cy4uPcU3AWVPGrbn5PhDBf3Froguzzhk++ami+r3Qrx5bIbY3TVzgiFI7Gq3
# zWcxggWtMIIFqQIBATBRMD0xOzA5BgNVBAMMMlZDRjkgUmVhZGluZXNzIExvY2Fs
# IENvZGUgU2lnbmluZyAoeGFkbWluQEhPTUVMQUIpAhBUZ6AKJOtZhET4y/4hrL7f
# MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJ
# KoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQB
# gjcCARUwLwYJKoZIhvcNAQkEMSIEIDpJ6bK3058wDoqJ1mactCG9Qml+BQEIcGzz
# 4AD63lcuMA0GCSqGSIb3DQEBAQUABIIBgLo2LkK6S2DfAceIddgJfANIS69vDaCE
# Xz/lChrAG97s7+QGpz5FxITmUxGrK0TmYcHkU4G2CHxZ+1ZWlaVVCphSdIBRfoZT
# DdhDJUIoKDvlW1BfsXMCn58UkWwC0jhis9SfoAZ+tbpgy2eVq0el0+ZI6WoGners
# GtrXusVvOgKBEmZoOIjJW9WK+6ebT7zYX0CU1q9IUyzhm6H7+gzEVp1CwMKAQVCl
# Rp6naInPj8MyHjyxPzD+dEMlcne9s4H9fkn+21GwJ6uSha204TshtXpLhBQ6lfu7
# e3JSzdjQC3h6IjVTpb++NX+J/MRAm10CFhC0tH0hKDOZrZHobAClMYsHiXNR/t3o
# GLjCZXawUuQqhYIprAFb+O5C7PtpCJWH5+BeEDFztvpAsd7fY/wgh6F0/Zqd4LJU
# ghuiEGAqRpAly/LrQWRv67pjEZs585715rm4Q3NlmN+iUtlOAWdcF8kh3pN8hsdk
# oinH1QO0t4T4ZlH/F+o8Sb8uLKipY3dteKGCAyYwggMiBgkqhkiG9w0BCQYxggMT
# MIIDDwIBATB9MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5j
# LjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcgUlNB
# NDA5NiBTSEEyNTYgMjAyNSBDQTECEAqA7xhLjfEFgtHEdqeVdGgwDQYJYIZIAWUD
# BAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEP
# Fw0yNTExMDYyMzA1MjRaMC8GCSqGSIb3DQEJBDEiBCB6Cdx+0pCyIjM408Mn2s9e
# Xa2U76iMijBtiwVVwE+ukTANBgkqhkiG9w0BAQEFAASCAgBa4qr+vlGx7MZfITKb
# RmTZrAUF6gjlFXFkGPaCgc8GdenPC4TDLDW7OcRllSg40jNEItUo8thVCn1ipqGr
# VBSxwymw0CDwuAn3SrhuNjKkN6yD+wK0yTjXzR1QBVOVRhKsNLFzw1MuO6ZZ78GC
# aowejbKwzTW8O/Htl4AturOWqj3YgqhQsOjkt+qrI3mHsyKHvUdlclJ0yuLvP7jD
# BT/+OqFd86yxNx3kAa+Va83FRz9raHGpo2ue/MdaGz6AajRqsIU8MAym7MiRXzI4
# IZeU7Zctz4Jx0zPJIvtiPML0+HsIbHIuMIPjCUoUqTCtIRyIki6Y6iBrBQU4WOJg
# W+tN/VrBdNF9AwF/AALkhfmLz/R6KNRQ9VjCraOtnP96LtjB6wlj8W+EiGj/2N5M
# jtKI3Of9yN+llDzLif1SB2vTv1bV0nqVxGrbUih199JHyNswgEJb5WF88KiQZ9Vy
# WWuqSwaLnnfksPch8n12tkaJmmNZbYTZk1Po1NomBFnPU9gim7yZIoAUVoWGC74s
# YULSj1bRV9hcQ8xGZl/f05IlW9WtkRaZe5LIOUPLtRpkDM9GeZa23JbfG6CvmH9c
# 8GhmaArr1OJ+bOuSRwWhW1EJs/RLy80O00fMI/gHX+rbq5SmYaMRtCzaXPhmLfmY
# fiTpCNn4/UGwCmgsThJaVPoZiw==
# SIG # End signature block
